﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HMS_Entities;
using HMS.Exceptions;
using HMS.DAL;
using System.Text.RegularExpressions;
using System.IO;

namespace HMS.BLL
{
    public class HMS_BLL
    {
        private static bool ValidatePatient(Patient patient)
        {
            StringBuilder sb = new StringBuilder();
            bool validPatient = true;
            if (patient.PatientId == string.Empty)
            {
                validPatient = false;
                sb.Append(Environment.NewLine + "Patient Id is Required cannot be blank");

            }
            if (!Regex.IsMatch(patient.PatientId, @"[0-9]{4}-[0-9]{4}"))
            {
                validPatient = false;
                sb.Append(Environment.NewLine + "PatientId is invalid ..");
            }

            if (patient.PatientName == string.Empty)
            {
                validPatient = false;
                sb.Append(Environment.NewLine + "Patient Name Required");

            }
            else if (!Regex.IsMatch(patient.PatientName, "^[A-Z][a-z]+"))
            {
                sb.Append("Patient name should start with Capital letter and it should have alphabets only\n");
                validPatient = false;
            }
            //if (patient.PatientId == string.Empty)
            //{
            //    sb.Append(Environment.NewLine + "Patient Id is required cannnot be blank");
            //    validPatient = false;
            //}
            //if (patient.PatientName == string.Empty)
            //{
            //    sb.Append(Environment.NewLine + "Patient Name is Required");
            //    validPatient = false;
            //}
            if (patient.PhoneNo.Length < 10)
            {
                sb.Append(Environment.NewLine + "Phone Number should have 10 digits");
                validPatient = false;
            }
            else if (!Regex.IsMatch(patient.PhoneNo, "[7-9][0-9]{9}"))
            {
                sb.Append("Phone number should start with 7 or 8 or 9 and it should have exactly 10 digits\n");
                validPatient = false;
            }
            if (validPatient == false)
                throw new HMS_Exception(sb.ToString());
            return validPatient;

        }

        private static bool ValidateAppointment(Appointment appointment)
        {
            StringBuilder sb = new StringBuilder();
            bool validAppointment = true;
            if (appointment.AppointmentId == string.Empty)
            {
                sb.Append(Environment.NewLine + "Appointment Id is required cannnot be blank");
                validAppointment = false;
            }
            if (appointment.PatientId == string.Empty)
            {
                sb.Append(Environment.NewLine + "Patient Id is required cannnot be blank");
                validAppointment = false;
            }
            if (validAppointment == false)
                throw new HMS_Exception(sb.ToString());
            return validAppointment;
        }

        private static bool ValidateBill(Bill bill)
        {
            StringBuilder sb = new StringBuilder();
            bool validBill = true;
            if (bill.BillId == string.Empty)
            {
                sb.Append(Environment.NewLine + "Bill Id is required cannnot be blank");
                validBill = false;
            }
            if (bill.PatientId == string.Empty)
            {
                sb.Append(Environment.NewLine + "Patient Id is required cannnot be blank");
                validBill = false;
            }
            if (bill.DoctorId == string.Empty)
            {
                sb.Append(Environment.NewLine + "Doctor Id is required cannnot be blank");
                validBill = false;
            }
            if (validBill == false)
                throw new HMS_Exception(sb.ToString());
            return validBill;
        }

        private static bool ValidateLab(Lab lab)
        {
            StringBuilder sb = new StringBuilder();
            bool validLab = true;
            if (lab.LabId == string.Empty)
            {
                sb.Append(Environment.NewLine + "Lab Id is required cannnot be blank");
                validLab = false;
            }
            if (lab.PatientId == string.Empty)
            {
                sb.Append(Environment.NewLine + "Patient Id is required cannnot be blank");
                validLab = false;
            }
            if (lab.DoctorId == string.Empty)
            {
                sb.Append(Environment.NewLine + "Doctor Id is required cannnot be blank");
                validLab = false;
            }
            if (validLab == false)
                throw new HMS_Exception(sb.ToString());
            return validLab;
        }

        public static bool AddPatientBLL(Patient newPatient)
        {
            bool patientAdded = false;
            try
            {
                if (ValidatePatient(newPatient))
                {
                    patientAdded = HMS_DAL.AddPatientDAL(newPatient);
                }
            }
            catch (HMS_Exception ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return patientAdded;
        }

        public static bool AddPatientAppointmentDataBLL(Appointment newAppointment)
        {
            bool patientAppointmentDataAdded = false;
            try
            {
                if (ValidateAppointment(newAppointment))
                {
                    patientAppointmentDataAdded = HMS_DAL.AddPatientAppointmentDataDAL(newAppointment);
                }
            }
            catch (HMS_Exception ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return patientAppointmentDataAdded;
        }

        public static List<Patient> GetAllPatientsBLL()
        {
            List<Patient> patientList = null;
            try
            {
                patientList = HMS_DAL.GetAllPatientsDAL();
            }
            catch (HMS_Exception ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return patientList;
        }

        public static List<Appointment> GetAllPatientsAppointmentDataBLL()
        {
            List<Appointment> appointmentList = null;
            try
            {
                appointmentList = HMS_DAL.GetAllPatientsAppointmentDataDAL();
            }
            catch (HMS_Exception ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return appointmentList;
        }

        public static bool DeletePatientBLL(string deletePatientID)
        {
            bool patientDeleted = false;
            try
            {
                if (deletePatientID != null)
                {
                    patientDeleted = HMS_DAL.DeletePatientDAL(deletePatientID);
                }
                else
                {
                    throw new HMS_Exception("Invalid Patient ID");
                }
            }
            catch (HMS_Exception ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return patientDeleted;
        }

        public static bool DeletePatientAppointmentDetailsBLL(string deletePatientAppointmentID)
        {
            bool patientAppointmentDeleted = false;
            try
            {
                if (deletePatientAppointmentID != null)
                {
                    patientAppointmentDeleted = HMS_DAL.DeletePatientAppointmentDetailsDAL(deletePatientAppointmentID);
                }
                else
                {
                    throw new HMS_Exception("Invalid Patient's Appointment ID");
                }
            }
            catch (HMS_Exception ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return patientAppointmentDeleted;
        }

        public static bool DeletePatientBillBLL(string deletePatientBillID)
        {
            bool patientBillDeleted = false;
            try
            {
                if (deletePatientBillID != null)
                {
                    patientBillDeleted = HMS_DAL.DeletePatientBillDAL(deletePatientBillID);
                }
                else
                {
                    throw new HMS_Exception("Invalid Patient's Bill ID");
                }
            }
            catch (HMS_Exception ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return patientBillDeleted;
        }

        public static bool DeletePatientLabReportBLL(string deletePatientLabReportID)
        {
            bool patientLabReportDeleted = false;
            try
            {
                if (deletePatientLabReportID != null)
                {
                    patientLabReportDeleted = HMS_DAL.DeletePatientLabReportDAL(deletePatientLabReportID);
                }
                else
                {
                    throw new HMS_Exception("Invalid Patient's Lab Report ID");
                }
            }
            catch (HMS_Exception ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return patientLabReportDeleted;
        }

        public static Patient SearchPatientBLL(string searchPatientID)
        {
            Patient searchPatient = null;
            try
            {
                searchPatient = HMS_DAL.SearchPatientDAL(searchPatientID);
            }
            catch (HMS_Exception ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchPatient;

        }
        public static Appointment SearchPatientByDoctorBLL(string searchPatientDOC)
        {
            Appointment searchPatientdoc = null;
            try
            {
                searchPatientdoc = HMS_DAL.SearchPatientDOCDAL(searchPatientDOC);
            }
            catch (HMS_Exception ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchPatientdoc;

        }

        public static Appointment SearchPatientDOVBLL(DateTime searchPatientDOV)
        {
            Appointment searchPatientdov = null;
            try
            {
                searchPatientdov = HMS_DAL.SearchPatientDOVDAL(searchPatientDOV);
            }
            catch (HMS_Exception ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchPatientdov;

        }
        public static Appointment SearchPatientDOABLL(DateTime searchPatientDOA)
        {
            Appointment searchPatientdoa = null;
            try
            {
                searchPatientdoa = HMS_DAL.SearchPatientDOADAL(searchPatientDOA);
            }
            catch (HMS_Exception ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchPatientdoa;

        }
        public static Appointment SearchPatientDODBLL(DateTime searchPatientDOD)
        {
            Appointment searchPatientdod = null;
            try
            {
                searchPatientdod = HMS_DAL.SearchPatientDODDAL(searchPatientDOD);
            }
            catch (HMS_Exception ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchPatientdod;

        }

        public static bool UpdatePatientBLL(Patient updatePatient)
        {
            bool patientUpdated = false;
            try
            {
                if (ValidatePatient(updatePatient))
                {
                    HMS_DAL patientDAL = new HMS_DAL();
                    patientUpdated = HMS_DAL.UpdatePatientDAL(updatePatient);
                }
            }
            catch (HMS_Exception ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return patientUpdated;
        }

        public static bool AddPatientBillBLL(Bill newBill)

        {
            bool patientBillReportDataAdded = false;
            try
            {
                if (ValidateBill(newBill))
                {
                    patientBillReportDataAdded = HMS_DAL.AddPatientBillDAL(newBill);
                }
            }
            catch (HMS_Exception ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return patientBillReportDataAdded;
        }

        public static List<Bill> GetAllPatientBillBLL()
        {
            List<Bill> billList = null;
            try
            {
                billList = HMS_DAL.GetAllPatientBillDAL();
            }
            catch (HMS_Exception ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return billList;
        }

        public static bool AddPatientLabReportBLL(Lab newLabReport)
        {
            bool patientLabReportAdded = false;
            try
            {
                if (ValidateLab(newLabReport))
                {
                    patientLabReportAdded = HMS_DAL.AddPatientLabReportDAL(newLabReport);
                }
            }
            catch (HMS_Exception ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return patientLabReportAdded;
        }

        public static List<Lab> GetAllPatientLabReportBLL()
        {
            List<Lab> labList = null;
            try
            {
                labList = HMS_DAL.GetAllPatientLabReportDAL();
            }
            catch (HMS_Exception ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return labList;
        }

        public static Bill SearchBillByIdBLL(string searchBillID)
        {
            Bill searchBill = null;
            try
            {
                searchBill = HMS_DAL.SearchBillByIdDAL(searchBillID);
            }
            catch (HMS_Exception ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchBill;
        }

        public static Lab SearchReportByIdBLL(string searchReportID)
        {
            Lab searchReport = null;
            try
            {
                searchReport = HMS_DAL.SearchReportByIdDAL(searchReportID);
            }
            catch (HMS_Exception ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchReport;

        }



        public static void SetSerialization()
        {

            if (HMS_DAL.patientList != null)
            {
                HMS_DAL.SetSerialization();
            }
        }
        public static void setList()
        {
            try
            {
                if (File.Exists(Directory.GetCurrentDirectory() + "\\" + HMS_DAL.fileName))
                    HMS_DAL.SetList();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

        }
    }
}

  