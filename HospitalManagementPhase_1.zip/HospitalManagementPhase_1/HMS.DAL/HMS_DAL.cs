﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HMS_Entities;
using HMS.Exceptions;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace HMS.DAL
{
    public class HMS_DAL
    {
        public static List<Patient> patientList = new List<Patient>();
        public static List<Appointment> appointmentList = new List<Appointment>();
        public static List<Bill> billList = new List<Bill>();
        public static List<Lab> labList = new List<Lab>();
        public static string fileName = "PatientList";
        public static bool AddPatientDAL(Patient newPatient)
        {
            bool patientAdded = false;
            try
            {
                patientList.Add(newPatient);
                patientAdded = true;
                SetSerialization();
            }
            catch (Exception ex)
            {
                throw new HMS_Exception(ex.Message);
            }
            return patientAdded;
        }

        public static bool AddPatientAppointmentDataDAL(Appointment newAppointment)
        {
            bool appointmentAdded = false;
            try
            {
                appointmentList.Add(newAppointment);
                appointmentAdded = true;
                SetSerialization();
            }
            catch (Exception ex)
            {
                throw new HMS_Exception(ex.Message);
            }
            return appointmentAdded;
        }

        public static List<Patient> GetAllPatientsDAL()
        {
            return patientList;
        }

        public static List<Appointment> GetAllPatientsAppointmentDataDAL()
        {
            return appointmentList;
        }

        public static bool DeletePatientDAL(string deletepatientID)
        {
            bool patientDeleted = false;
            try
            {
                for (int i = 0; i < patientList.Count; i++)
                {
                    Patient patient = patientList[i];
                    if (patient.PatientId == deletepatientID)
                    {
                        patientList.RemoveAt(i);
                        patientDeleted = true;
                        SetSerialization();
                        break;
                    }
                }

            }
            catch (Exception ex)
            {
                throw new HMS_Exception(ex.Message);
            }
            return patientDeleted;
        }

        public static bool DeletePatientAppointmentDetailsDAL(string deletePatientAppointmentID)
        {
            bool patientAppointmentDeleted = false;
            try
            {
                for (int i = 0; i < appointmentList.Count; i++)
                {
                    Appointment appointment = appointmentList[i];
                    if (appointment.AppointmentId == deletePatientAppointmentID)
                    {
                        appointmentList.RemoveAt(i);
                        patientAppointmentDeleted = true;
                        SetSerialization();
                        break;
                    }
                }

            }
            catch (Exception ex)
            {
                throw new HMS_Exception(ex.Message);
            }
            return patientAppointmentDeleted;
        }

        public static bool DeletePatientBillDAL(string deletePatientBillID)
        {
            bool patientBillDeleted = false;
            try
            {
                for (int i = 0; i < billList.Count; i++)
                {
                    Bill bill = billList[i];
                    if (bill.BillId == deletePatientBillID)
                    {
                        billList.RemoveAt(i);
                        patientBillDeleted = true;
                        SetSerialization();
                        break;
                    }
                }

            }
            catch (Exception ex)
            {
                throw new HMS_Exception(ex.Message);
            }
            return patientBillDeleted;
        }

        public static bool DeletePatientLabReportDAL(string deletePatientLabReportID)
        {
            bool patientLabReportDeleted = false;
            try
            {
                for (int i = 0; i < labList.Count; i++)
                {
                    Lab lab = labList[i];
                    if (lab.LabId == deletePatientLabReportID)
                    {
                        labList.RemoveAt(i);
                        patientLabReportDeleted = true;
                        SetSerialization();
                        break;
                    }
                }

            }
            catch (Exception ex)
            {
                throw new HMS_Exception(ex.Message);
            }
            return patientLabReportDeleted;
        }

        public static Patient SearchPatientDAL(string searchPatientID)
        {
            Patient searchPatient = null;
            try
            {
                for (int i = 0; i < patientList.Count; i++)
                {
                    Patient patient = patientList[i];
                    if (patient.PatientId == searchPatientID)
                    {
                        searchPatient = patientList[i];
                        break;
                    }
                }
            }
            catch (Exception ex)
            {
                throw new HMS_Exception(ex.Message);
            }
            return searchPatient;
        }
        public static Appointment SearchPatientDOCDAL(string searchPatientDOC)
        {
            Appointment searchPatientdoc = null;
            try
            {
                for (int i = 0; i < appointmentList.Count; i++)
                {
                    Appointment patient = appointmentList[i];
                    if (patient.DoctorName == searchPatientDOC)
                    {
                        searchPatientdoc = appointmentList[i];
                        break;
                    }
                }
            }
            catch (Exception ex)
            {
                throw new HMS_Exception(ex.Message);
            }
            return searchPatientdoc;
        }

        public static Appointment SearchPatientDOVDAL(DateTime searchPatientDOV)
        {
            Appointment searchPatientdov = null;
            try
            {
                for (int i = 0; i < appointmentList.Count; i++)
                {
                    Appointment appointment = appointmentList[i];
                    if (appointment.DateOfVisit == searchPatientDOV)
                    {
                        searchPatientdov = appointmentList[i];
                        break;
                    }
                }
            }
            catch (Exception ex)
            {
                throw new HMS_Exception(ex.Message);
            }
            return searchPatientdov;
        }

        public static Appointment SearchPatientDOADAL(DateTime searchPatientDOA)
        {
            Appointment searchPatientdoa = null;
            try
            {
                for (int i = 0; i < appointmentList.Count; i++)
                {
                    Appointment appointment = appointmentList[i];
                    if (appointment.AdmissionDate == searchPatientDOA)
                    {
                        searchPatientdoa = appointmentList[i];
                        break;
                    }
                }
            }
            catch (Exception ex)
            {
                throw new HMS_Exception(ex.Message);
            }
            return searchPatientdoa;
        }
        public static Appointment SearchPatientDODDAL(DateTime searchPatientDOD)
        {
            Appointment searchPatientdod = null;
            try
            {
                for (int i = 0; i < appointmentList.Count; i++)
                {
                    Appointment appointment = appointmentList[i];
                    if (appointment.DischargeDate == searchPatientDOD)
                    {
                        searchPatientdod = appointmentList[i];
                        break;
                    }
                }
            }
            catch (Exception ex)
            {
                throw new HMS_Exception(ex.Message);
            }
            return searchPatientdod;
        }

        public static bool UpdatePatientDAL(Patient updatePatient)
        {
            bool patientUpdated = false;
            try
            {
                for (int i = 0; i < patientList.Count; i++)
                {
                    Patient patient = patientList[i];
                    if (patient.PatientId == updatePatient.PatientId)
                    {
                        patientList[i] = updatePatient;
                        SetSerialization();
                        break;
                    }
                }
                patientUpdated = true;
            }
            catch (Exception ex)
            {
                throw new HMS_Exception(ex.Message);
            }
            return patientUpdated;
        }

        public static bool AddPatientBillDAL(Bill newBill)
        {
            bool billAdded = false;
            try
            {
                billList.Add(newBill);
                billAdded = true;
                SetSerialization();
            }
            catch (Exception ex)
            {
                throw new HMS_Exception(ex.Message);
            }
            return billAdded;
        }

        public static List<Bill> GetAllPatientBillDAL()
        {
            return billList;
        }

        public static bool AddPatientLabReportDAL(Lab newLabReport)
        {
            bool labReportAdded = false;
            try
            {
                labList.Add(newLabReport);
                labReportAdded = true;
                SetSerialization();
            }
            catch (Exception ex)
            {
                throw new HMS_Exception(ex.Message);
            }
            return labReportAdded;
        }

        public static List<Lab> GetAllPatientLabReportDAL()
        {
            return labList;
        }

        public static Bill SearchBillByIdDAL(string searchBillID)
        {
            Bill searchBill = null;
            try
            {
                for (int i = 0; i < billList.Count; i++)
                {
                    Bill bill = billList[i];
                    if (bill.BillId == searchBillID)
                    {
                        searchBill = billList[i];
                        break;
                    }
                }
            }
            catch (Exception ex)
            {
                throw new HMS_Exception(ex.Message);
            }
            return searchBill;
        }

        public static Lab SearchReportByIdDAL(string searchReportID)
        {
            Lab searchReport = null;
            try
            {
                for (int i = 0; i < labList.Count; i++)
                {
                    Lab lab = labList[i];
                    if (lab.LabId == searchReportID)
                    {
                        searchReport = labList[i];
                        break;
                    }
                }
            }
            catch (Exception ex)
            {
                throw new HMS_Exception(ex.Message);
            }
            return searchReport;
        }



        public static void SetSerialization()
        {
            try
            {
                using (Stream file = File.Open(fileName, FileMode.Create))
                {
                    BinaryFormatter bf = new BinaryFormatter();
                    bf.Serialize(file, patientList);
                    bf.Serialize(file, appointmentList);
                    bf.Serialize(file, billList);
                    bf.Serialize(file, labList);
                    file.Close();
                }
            }
            catch (FileNotFoundException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

        }

        public static void SetList()
        {
            DeserializeFile();
        }
        public static void DeserializeFile()
        {
            try
            {
                using (Stream file = File.Open(Directory.GetCurrentDirectory() + "\\" + fileName, FileMode.Open))
                {
                    BinaryFormatter bf = new BinaryFormatter();
                    patientList = bf.Deserialize(file) as List<Patient>;
                    appointmentList = bf.Deserialize(file) as List<Appointment>;
                    billList = bf.Deserialize(file) as List<Bill>;
                    labList = bf.Deserialize(file) as List<Lab>;
                    file.Close();
                }
            }
            catch (FileNotFoundException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
   
    }
}
