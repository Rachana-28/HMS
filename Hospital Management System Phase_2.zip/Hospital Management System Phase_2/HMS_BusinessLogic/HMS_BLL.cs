﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using HMS_Exception;
using HMS_Entities;
using System.Data;
using HMS_DataAccess;
using System.Data.SqlClient;

namespace HMS_BusinessLogic
{
    public class HMS_BLL
    { 
    private static bool ValidatePatient(Patient patient)
    {
        StringBuilder sb = new StringBuilder();
        bool validPatient = true;
        try
        {
            if (patient.PatientId == string.Empty)
            {
                sb.Append(Environment.NewLine + "Patient Id is required cannnot be blank");
                validPatient = false;
            }
            if (patient.PatientName == string.Empty)
            {
                sb.Append(Environment.NewLine + "Patient Name is Required");
                validPatient = false;
            }
            if (patient.Gender == "Select")
            {
                sb.Append(Environment.NewLine + "Gender Id is Required");
                validPatient = false;
            }
            if (patient.PhoneNo.Length < 10)
            {
                sb.Append(Environment.NewLine + "Phone Number should have 10 digits");
                validPatient = false;
            }
            else if (!Regex.IsMatch(patient.PhoneNo, "[6-9][0-9]{9}"))
            {
                sb.Append("Phone number should start with 6 or 7 or 8 or 9 and it should have exactly 10 digits\n");
                validPatient = false;
            }
            if (patient.DoctorId == "Select")
            {
                sb.Append(Environment.NewLine + "Doctor Id is Required");
                validPatient = false;
            }
            if (validPatient == false)
                throw new HMS_Exception.HMS_Exception(sb.ToString());
        }
        catch (HMS_Exception.HMS_Exception ex)
        {
            throw ex;
        }
        catch (Exception ex)
        {
            throw ex;
        }
        return validPatient;

    }

    private static bool ValidateAppointment(Appointment appointment)
    {
        StringBuilder sb = new StringBuilder();
        bool validAppointment = true;
        try
        {
            if (appointment.AppointmentId == string.Empty)
            {
                sb.Append(Environment.NewLine + "Appointment Id is required cannnot be blank");
                validAppointment = false;
            }
            if (appointment.PatientId == string.Empty)
            {
                sb.Append(Environment.NewLine + "Patient Id is required cannnot be blank");
                validAppointment = false;
            }
            if (validAppointment == false)
                throw new HMS_Exception.HMS_Exception(sb.ToString());
        }
        catch (HMS_Exception.HMS_Exception ex)
        {
            throw ex;
        }
        catch (Exception ex)
        {
            throw ex;
        }
        return validAppointment;
    }

    private static bool ValidateBill(Bill bill)
    {
        StringBuilder sb = new StringBuilder();
        bool validBill = true;
        try
        {
            if (bill.BillId == string.Empty)
            {
                sb.Append(Environment.NewLine + "Bill Id is required cannnot be blank");
                validBill = false;
            }
            if (bill.PatientId == string.Empty)
            {
                sb.Append(Environment.NewLine + "Patient Id is required cannnot be blank");
                validBill = false;
            }
            else if (bill.PatientId == "Select")
            {
                sb.Append(Environment.NewLine + "Patient Id is required");
                validBill = false;
            }
            if (bill.DoctorId == string.Empty)
            {
                sb.Append(Environment.NewLine + "Doctor Id is required cannnot be blank");
                validBill = false;
            }
            else if (bill.DoctorId == "Select")
            {
                sb.Append(Environment.NewLine + "Doctor Id is Required");
                validBill = false;
            }
            if (validBill == false)
                throw new HMS_Exception.HMS_Exception(sb.ToString());
        }
        catch (HMS_Exception.HMS_Exception ex)
        {
            throw ex;
        }
        catch (Exception ex)
        {
            throw ex;
        }
        return validBill;
    }

    private static bool ValidateLab(Lab lab)
    {
        StringBuilder sb = new StringBuilder();
        bool validLab = true;
        try
        {
            if (lab.LabId == string.Empty)
            {
                sb.Append(Environment.NewLine + "Lab Id is required cannnot be blank");
                validLab = false;
            }
            if (lab.PatientId == string.Empty)
            {
                sb.Append(Environment.NewLine + "Patient Id is required cannnot be blank");
                validLab = false;
            }
            else if (lab.PatientId == "Select")
            {
                sb.Append(Environment.NewLine + "Patient Id is Required");
                validLab = false;
            }
            if (lab.DoctorId == string.Empty)
            {
                sb.Append(Environment.NewLine + "Doctor Id is required cannnot be blank");
                validLab = false;
            }
            if (validLab == false)
                throw new HMS_Exception.HMS_Exception(sb.ToString());
        }
        catch (HMS_Exception.HMS_Exception ex)
        {
            throw ex;
        }
        catch (Exception ex)
        {
            throw ex;
        }
        return validLab;
    }

    private static bool ValidateInPatient(InPatient inPatient)
    {
        StringBuilder sb = new StringBuilder();
        bool validInPatient = true;
        try
        {
            if (inPatient.LabId == string.Empty)
            {
                sb.Append(Environment.NewLine + "Lab Id is required cannnot be blank");
                validInPatient = false;
            }
            else if (inPatient.LabId == "Select")
            {
                sb.Append(Environment.NewLine + "Lab Id is Required");
                validInPatient = false;
            }
            if (inPatient.PatientId == string.Empty)
            {
                sb.Append(Environment.NewLine + "Patient Id is required cannnot be blank");
                validInPatient = false;
            }
            if (inPatient.RoomId == string.Empty)
            {
                sb.Append(Environment.NewLine + "Room Id is required cannnot be blank");
                validInPatient = false;
            }

            else if (inPatient.RoomId == "Select")
            {
                sb.Append(Environment.NewLine + "Room Id is Required");
                validInPatient = false;
            }
            if (inPatient.DoctorId == string.Empty)
            {
                sb.Append(Environment.NewLine + "Doctor Id is required cannnot be blank");
                validInPatient = false;
            }
            else if (inPatient.DoctorId == "Select")
            {
                sb.Append(Environment.NewLine + "Doctor Id is Required");
                validInPatient = false;
            }
            if (inPatient.AdmissionDate == null)
            {
                sb.Append(Environment.NewLine + "Admission Date is Required");
                validInPatient = false;
            }
            if (inPatient.DischargeDate == null)
            {
                sb.Append(Environment.NewLine + "Discharge Date is Required");
                validInPatient = false;
            }
            if (inPatient.AmountPerDay <= 0)
            {
                sb.Append(Environment.NewLine + "Enter the Amount Per Day");
                validInPatient = false;
            }
            if (validInPatient == false)
                throw new HMS_Exception.HMS_Exception(sb.ToString());
        }
        catch (HMS_Exception.HMS_Exception ex)
        {
            throw ex;
        }
        catch (Exception ex)
        {
            throw ex;
        }
        return validInPatient;
    }

    private static bool ValidateOutPatient(OutPatient outPatient)
    {
        StringBuilder sb = new StringBuilder();
        bool validOutPatient = true;
        try
        {
            if (outPatient.LabId == string.Empty)
            {
                sb.Append(Environment.NewLine + "Lab Id is required cannnot be blank");
                validOutPatient = false;
            }
            else if (outPatient.LabId == "Select")
            {
                sb.Append(Environment.NewLine + "Lab Id is Required");
                validOutPatient = false;
            }
            if (outPatient.PatientId == string.Empty)
            {
                sb.Append(Environment.NewLine + "Patient Id is required cannnot be blank");
                validOutPatient = false;
            }
            if (outPatient.DoctorId == string.Empty)
            {
                sb.Append(Environment.NewLine + "Doctor Id is required cannnot be blank");
                validOutPatient = false;
            }
            else if (outPatient.DoctorId == "Select")
            {
                sb.Append(Environment.NewLine + "Doctor Id is Required");
                validOutPatient = false;
            }
            if (outPatient.TreatmentDate == null)
            {
                sb.Append(Environment.NewLine + "Treatment Date is Required");
                validOutPatient = false;
            }
            if (validOutPatient == false)
                throw new HMS_Exception.HMS_Exception(sb.ToString());
        }
        catch (HMS_Exception.HMS_Exception ex)
        {
            throw ex;
        }
        catch (Exception ex)
        {
            throw ex;
        }
        return validOutPatient;
    }

    public static int AddPatientBLL(Patient newPatient)
    {
        int patientAdded = 0;
        try
        {
            if (ValidatePatient(newPatient))
            {
                patientAdded = HMS_DAL.AddPatientDAL(newPatient);
            }
        }
        catch (HMS_Exception.HMS_Exception ex)
        {
            throw ex;
        }
        catch (Exception ex)
        {
            throw ex;
        }
        return patientAdded;
    }

    public static DataTable GetAllPatientsBLL()
    {
        DataTable dtPatient = null;
        try
        {
            dtPatient = HMS_DAL.GetAllPatientsDAL();
        }
        catch (HMS_Exception.HMS_Exception ex)
        {
            throw ex;
        }
        catch (Exception ex)
        {
            throw ex;
        }
        return dtPatient;
    }

    public static int DeletePatientBLL(string deletePatientID)
    {
        int patientDeleted = 0;
        try
        {
            if (deletePatientID != null)
            {
                patientDeleted = HMS_DAL.DeletePatientDAL(deletePatientID);
            }
            else
            {
                throw new HMS_Exception.HMS_Exception("Invalid Patient ID");
            }
        }
        catch (HMS_Exception.HMS_Exception)
        {
            throw;
        }
        catch (Exception ex)
        {
            throw ex;
        }
        return patientDeleted;
    }

    public static Patient SearchPatientBLL(string searchPatientID)
    {
        Patient searchPatient = null;
        try
        {
            searchPatient = HMS_DAL.SearchPatientDAL(searchPatientID);
        }
        catch (HMS_Exception.HMS_Exception ex)
        {
            throw ex;
        }
        catch (Exception ex)
        {
            throw ex;
        }
        return searchPatient;
    }

    public static DataSet SearchPatientByDoctorBLL(string searchPatientID)
    {
        DataSet dataSet = new DataSet();// searchPatient = null;
        try
        {
            dataSet = HMS_DAL.SearchPatientByDoctorDAL(searchPatientID);
        }
        catch (HMS_Exception.HMS_Exception ex)
        {
            throw ex;
        }
        catch (Exception ex)
        {
            throw ex;
        }
        return dataSet;
    }

    public static int UpdatePatientBLL(Patient updatePatient)
    {
        int patientUpdated = 0;
        try
        {
            if (ValidatePatient(updatePatient))
            {
                //HMS_DAL patientDAL = new HMS_DAL();
                patientUpdated = HMS_DAL.UpdatePatientDAL(updatePatient);
            }
        }
        catch (HMS_Exception.HMS_Exception)
        {
            throw;
        }
        catch (Exception ex)
        {
            throw ex;
        }

        return patientUpdated;
    }

    //public static int AddPatientAppointmentBLL(Appointment newAppointment)
    //{
    //    int patientAppointmentAdded = 0;
    //    try
    //    {
    //        if (ValidateAppointment(newAppointment))
    //        {
    //            patientAppointmentAdded = HMS_DAL.AddPatientAppointmentDAL(newAppointment);
    //        }
    //    }
    //    catch (HMS_Exception.HMS_Exception ex)
    //    {
    //        throw ex;
    //    }
    //    catch (Exception ex)
    //    {
    //        throw ex;
    //    }
    //    return patientAppointmentAdded;
    //}

    //public static DataTable GetAllPatientsAppointmentBLL()
    //{
    //    DataTable dtAppointment = null;
    //    try
    //    {
    //        dtAppointment = HMS_DAL.GetAllPatientsAppointmentDAL();
    //    }
    //    catch (HMS_Exception.HMS_Exception ex)
    //    {
    //        throw ex;
    //    }
    //    catch (Exception ex)
    //    {
    //        throw ex;
    //    }
    //    return dtAppointment;
    //}

    //public static int DeletePatientAppointmentBLL(string deletePatientAppointmentID)
    //{
    //    int patientAppointmentDeleted = 0;
    //    try
    //    {
    //        if (deletePatientAppointmentID != null)
    //        {
    //            patientAppointmentDeleted = HMS_DAL.DeletePatientAppointmentDAL(deletePatientAppointmentID);
    //        }
    //        else
    //        {
    //            throw new HMS_Exception.HMS_Exception("Invalid Patient's Appointment ID");
    //        }
    //    }
    //    catch (HMS_Exception.HMS_Exception)
    //    {
    //        throw;
    //    }
    //    catch (Exception ex)
    //    {
    //        throw ex;
    //    }
    //    return patientAppointmentDeleted;
    //}

    //public static Appointment SearchPatientByDoctorBLL(string searchPatientDOC)
    //{
    //    Appointment searchPatientdoc = null;
    //    try
    //    {
    //        searchPatientdoc = HMS_DAL.SearchPatientDoctorDAL(searchPatientDOC);
    //    }
    //    catch (HMS_Exception.HMS_Exception ex)
    //    {
    //        throw ex;
    //    }
    //    catch (Exception ex)
    //    {
    //        throw ex;
    //    }
    //    return searchPatientdoc;

    //}

    //public static Appointment SearchPatientDOVBLL(DateTime searchPatientDOV)
    //{
    //    Appointment searchPatientdov = null;
    //    try
    //    {
    //        searchPatientdov = HMS_DAL.SearchPatientDOVDAL(searchPatientDOV);
    //    }
    //    catch (HMS_Exception.HMS_Exception ex)
    //    {
    //        throw ex;
    //    }
    //    catch (Exception ex)
    //    {
    //        throw ex;
    //    }
    //    return searchPatientdov;

    //}
    //public static Appointment SearchPatientDOABLL(DateTime searchPatientDOA)
    //{
    //    Appointment searchPatientdoa = null;
    //    try
    //    {
    //        searchPatientdoa = HMS_DAL.SearchPatientDODDAL(searchPatientDOA);
    //    }
    //    catch (HMS_Exception.HMS_Exception ex)
    //    {
    //        throw ex;
    //    }
    //    catch (Exception ex)
    //    {
    //        throw ex;
    //    }
    //    return searchPatientdoa;

    //}
    //public static Appointment SearchPatientDODBLL(DateTime searchPatientDOD)
    //{
    //    Appointment searchPatientdod = null;
    //    try
    //    {
    //        searchPatientdod = HMS_DAL.SearchPatientDODDAL(searchPatientDOD);
    //    }
    //    catch (HMS_Exception.HMS_Exception ex)
    //    {
    //        throw ex;
    //    }
    //    catch (Exception ex)
    //    {
    //        throw ex;
    //    }
    //    return searchPatientdod;
    //}

    public static int AddPatientBillBLL(Bill newBill)
    {
        int patientBillAdded = 0;
        try
        {
            if (ValidateBill(newBill))
            {
                patientBillAdded = HMS_DAL.AddPatientBillDAL(newBill);
            }
        }
        catch (HMS_Exception.HMS_Exception e)
        {
            throw e;
        }
        catch (Exception ex)
        {
            throw ex;
        }

        return patientBillAdded;
    }

    public static DataTable GetAllPatientBillBLL()
    {
        DataTable billList = null;
        try
        {
            billList = HMS_DAL.GetAllPatientBillDAL();
        }
        catch (HMS_Exception.HMS_Exception ex)
        {
            throw ex;
        }
        catch (Exception ex)
        {
            throw ex;
        }
        return billList;
    }

    public static Bill SearchBillByIdBLL(string searchBillID)
    {
        Bill searchBill = null;
        try
        {
            searchBill = HMS_DAL.SearchBillByIdDAL(searchBillID);
        }
        catch (HMS_Exception.HMS_Exception ex)
        {
            throw ex;
        }
        catch (Exception ex)
        {
            throw ex;
        }
        return searchBill;
    }

    public static int UpdateBillByIdBLL(Bill updateBill)
    {
        int billUpdated = 0;
        try
        {
            if (ValidateBill(updateBill))
            {
                //HMS_DAL patientDAL = new HMS_DAL();
                billUpdated = HMS_DAL.UpdateBillByIdDAL(updateBill);
            }
        }
        catch (HMS_Exception.HMS_Exception)
        {
            throw;
        }
        catch (Exception ex)
        {
            throw ex;
        }

        return billUpdated;
    }

    public static int DeletePatientBillBLL(string deletePatientBillID)
    {
        int patientBillDeleted = 0;
        try
        {
            if (deletePatientBillID != null)
            {
                patientBillDeleted = HMS_DAL.DeletePatientBillDAL(deletePatientBillID);
            }
            else
            {
                throw new HMS_Exception.HMS_Exception("Invalid Patient's Bill ID");
            }
        }
        catch (HMS_Exception.HMS_Exception)
        {
            throw;
        }
        catch (Exception ex)
        {
            throw ex;
        }
        return patientBillDeleted;
    }

    public static int AddPatientLabReportBLL(Lab newLabReport)
    {
        int patientLabReportAdded = 0;
        try
        {
            if (ValidateLab(newLabReport))
            {
                patientLabReportAdded = HMS_DAL.AddPatientLabReportDAL(newLabReport);
            }
        }
        catch (HMS_Exception.HMS_Exception e)
        {
            throw e;
        }
        catch (Exception ex)
        {
            throw ex;
        }

        return patientLabReportAdded;
    }

    public static DataTable GetAllPatientLabReportBLL()
    {
        DataTable labList = null;
        try
        {
            labList = HMS_DAL.GetAllPatientLabReportDAL();
        }
        catch (HMS_Exception.HMS_Exception ex)
        {
            throw ex;
        }
        catch (Exception ex)
        {
            throw ex;
        }
        return labList;
    }

    public static Lab SearchReportByIdBLL(string searchReportID)
    {
        Lab searchReport = null;
        try
        {
            searchReport = HMS_DAL.SearchReportByIdDAL(searchReportID);
        }
        catch (HMS_Exception.HMS_Exception ex)
        {
            throw ex;
        }
        catch (Exception ex)
        {
            throw ex;
        }
        return searchReport;

    }

    public static int DeletePatientLabReportBLL(string deletePatientLabReportID)
    {
        int patientLabReportDeleted = 0;
        try
        {
            if (deletePatientLabReportID != null)
            {
                patientLabReportDeleted = HMS_DAL.DeletePatientLabReportDAL(deletePatientLabReportID);
            }
            else
            {
                throw new HMS_Exception.HMS_Exception("Invalid Patient's Lab Report ID");
            }
        }
        catch (HMS_Exception.HMS_Exception)
        {
            throw;
        }
        catch (Exception ex)
        {
            throw ex;
        }
        return patientLabReportDeleted;
    }

    public static int UpdateLabReportByIdBLL(Lab updateLabReport)
    {
        int labReportUpdated = 0;
        try
        {
            if (ValidateLab(updateLabReport))
            {
                //HMS_DAL patientDAL = new HMS_DAL();
                labReportUpdated = HMS_DAL.UpdateLabReportByIdDAL(updateLabReport);
            }
        }
        catch (HMS_Exception.HMS_Exception)
        {
            throw;
        }
        catch (Exception ex)
        {
            throw ex;
        }

        return labReportUpdated;
    }

    public static int AddInPatientBLL(InPatient newInPatient)
    {
        int inPatientAdded = 0;
        try
        {
            if (ValidateInPatient(newInPatient))
            {
                inPatientAdded = HMS_DAL.AddInPatientDAL(newInPatient);
            }
        }
        catch (HMS_Exception.HMS_Exception ex)
        {
            throw ex;
        }
        catch (Exception ex)
        {
            throw ex;
        }
        return inPatientAdded;
    }

    public static DataTable GetAllInPatientsBLL()
    {
        DataTable dtInPatient = null;
        try
        {
            dtInPatient = HMS_DAL.GetAllInPatientsDAL();
        }
        catch (HMS_Exception.HMS_Exception ex)
        {
            throw ex;
        }
        catch (Exception ex)
        {
            throw ex;
        }
        return dtInPatient;
    }

    public static InPatient SearchInPatientBLL(string searchPatientID)
    {
        InPatient searchInPatient = null;
        try
        {
            searchInPatient = HMS_DAL.SearchInPatientDAL(searchPatientID);
        }
        catch (HMS_Exception.HMS_Exception ex)
        {
            throw ex;
        }
        catch (Exception ex)
        {
            throw ex;
        }
        return searchInPatient;
    }

    public static int UpdateInPatientBLL(InPatient updateInPatient)
    {
        int inPatientUpdated = 0;
        try
        {
            if (ValidateInPatient(updateInPatient))
            {
                //HMS_DAL patientDAL = new HMS_DAL();
                inPatientUpdated = HMS_DAL.UpdateInPatientDAL(updateInPatient);
            }
        }
        catch (HMS_Exception.HMS_Exception)
        {
            throw;
        }
        catch (Exception ex)
        {
            throw ex;
        }

        return inPatientUpdated;
    }

    public static int DeleteInPatientBLL(string deleteInPatientID)
    {
        int inPatientDeleted = 0;
        try
        {
            if (deleteInPatientID != null)
            {
                inPatientDeleted = HMS_DAL.DeleteInPatientDAL(deleteInPatientID);
            }
            else
            {
                throw new HMS_Exception.HMS_Exception("Invalid InPatient ID");
            }
        }
        catch (HMS_Exception.HMS_Exception)
        {
            throw;
        }
        catch (Exception ex)
        {
            throw ex;
        }
        return inPatientDeleted;
    }

    public static DataSet SearchInPatientByDoctorBLL(string searchInPatientByDoctorID)
    {
        DataSet dataSet = new DataSet();// searchPatient = null;
        try
        {
            dataSet = HMS_DAL.SearchInPatientByDoctorDAL(searchInPatientByDoctorID);
        }
        catch (HMS_Exception.HMS_Exception ex)
        {
            throw ex;
        }
        catch (Exception ex)
        {
            throw ex;
        }
        return dataSet;
    }

    public static DataSet SearchInPatientByRoomBLL(string searchInPatientByRoomID)
    {
        DataSet dataSet = new DataSet();// searchPatient = null;
        try
        {
            dataSet = HMS_DAL.SearchInPatientByRoomDAL(searchInPatientByRoomID);
        }
        catch (HMS_Exception.HMS_Exception ex)
        {
            throw ex;
        }
        catch (Exception ex)
        {
            throw ex;
        }
        return dataSet;
    }

    public static int AddOutPatientBLL(OutPatient newOutPatient)
    {
        int outPatientAdded = 0;
        try
        {
            if (ValidateOutPatient(newOutPatient))
            {
                outPatientAdded = HMS_DAL.AddOutPatientDAL(newOutPatient);
            }
        }
        catch (HMS_Exception.HMS_Exception ex)
        {
            throw ex;
        }
        catch (Exception ex)
        {
            throw ex;
        }
        return outPatientAdded;
    }

    public static DataTable GetAllOutPatientsBLL()
    {
        DataTable dtOutPatient = null;
        try
        {
            dtOutPatient = HMS_DAL.GetAllOutPatientsDAL();
        }
        catch (HMS_Exception.HMS_Exception ex)
        {
            throw ex;
        }
        catch (Exception ex)
        {
            throw ex;
        }
        return dtOutPatient;
    }

    public static OutPatient SearchOutPatientBLL(string searchPatientID)
    {
        OutPatient searchOutPatient = null;
        try
        {
            searchOutPatient = HMS_DAL.SearchOutPatientDAL(searchPatientID);
        }
        catch (HMS_Exception.HMS_Exception ex)
        {
            throw ex;
        }
        catch (Exception ex)
        {
            throw ex;
        }
        return searchOutPatient;
    }

    public static int DeleteOutPatientBLL(string deleteInPatientID)
    {
        int outPatientDeleted = 0;
        try
        {
            if (deleteInPatientID != null)
            {
                outPatientDeleted = HMS_DAL.DeleteOutPatientDAL(deleteInPatientID);
            }
            else
            {
                throw new HMS_Exception.HMS_Exception("Invalid OutPatient ID");
            }
        }
        catch (HMS_Exception.HMS_Exception)
        {
            throw;
        }
        catch (Exception ex)
        {
            throw ex;
        }
        return outPatientDeleted;
    }

    public static int UpdateOutPatientBLL(OutPatient updateOutPatient)
    {
        int outPatientUpdated = 0;
        try
        {
            if (ValidateOutPatient(updateOutPatient))
            {
                //HMS_DAL patientDAL = new HMS_DAL();
                outPatientUpdated = HMS_DAL.UpdateOutPatientDAL(updateOutPatient);
            }
        }
        catch (HMS_Exception.HMS_Exception)
        {
            throw;
        }
        catch (Exception ex)
        {
            throw ex;
        }

        return outPatientUpdated;
    }

    public static DataSet SearchOutPatientByDoctorBLL(string searchOutPatientByDoctorID)
    {
        DataSet dataSet = new DataSet();// searchPatient = null;
        try
        {
            dataSet = HMS_DAL.SearchOutPatientByDoctorDAL(searchOutPatientByDoctorID);
        }
        catch (HMS_Exception.HMS_Exception ex)
        {
            throw ex;
        }
        catch (Exception ex)
        {
            throw ex;
        }
        return dataSet;
    }

    public static DataSet SearchOutPatientByLabBLL(string searchOutPatientByLabID)
    {
        DataSet dataSet = new DataSet();// searchPatient = null;
        try
        {
            dataSet = HMS_DAL.SearchOutPatientByLabDAL(searchOutPatientByLabID);
        }
        catch (HMS_Exception.HMS_Exception ex)
        {
            throw ex;
        }
        catch (Exception ex)
        {
            throw ex;
        }
        return dataSet;
    }





    public static List<string> GetDoctorIdsBLL()
    {
        List<string> listObj = null;
        try
        {
            listObj = HMS_DAL.GetDoctorIdsDAL();
        }
        catch (SqlException ex)
        {
            throw ex;
        }
        catch (Exception ex)
        {
            throw ex;
        }
        return listObj;
    }

    public static List<string> GetPatientIds()
    {
        List<string> listObj = null;
        try
        {
            listObj = HMS_DAL.GetPatientIdsDAL();
        }
        catch (SqlException ex)
        {
            throw ex;
        }
        catch (Exception ex)
        {
            throw ex;
        }
        return listObj;
    }

    public static List<string> GetLabIdsBLL()
    {
        List<string> listObj = null;
        try
        {
            listObj = HMS_DAL.GetLabIdsDAL();
        }
        catch (SqlException ex)
        {
            throw ex;
        }
        catch (Exception ex)
        {
            throw ex;
        }
        return listObj;
    }

    public static List<string> GetRoomIdsBLL()
    {
        List<string> listObj = null;
        try
        {
            listObj = HMS_DAL.GetRoomIdsDAL();
        }
        catch (SqlException ex)
        {
            throw ex;
        }
        catch (Exception ex)
        {
            throw ex;
        }
        return listObj;
    }

}
}