﻿using HMS_BusinessLogic;
using HMS_Entities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace HMSWPF
{
    /// <summary>
    /// Interaction logic for InPatientWPF.xaml
    /// </summary>
    public partial class InPatientWPF : Window
    {
        public InPatientWPF()
        {
            InitializeComponent();
        }
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            RefreshInPatient();
            LoadDoctorIds();
            LoadLabIds();
            LoadRoomIds();
        }

        private void Clear()
        {
            pId.Text = "";
            roomId.Text = "Select";
            docId.Text = "Select";
            txtadmdate.Text = "";
            txtdisdate.Text = "";
            txtlabid.Text = "Select";
            txtamt.Text = "";
        }

        private void LoadDoctorIds()
        {
            List<string> listofids = HMS_BLL.GetDoctorIdsBLL();
            docId.ItemsSource = listofids;
            docId.Text = "Select";
        }

        private void LoadLabIds()
        {
            List<string> listofids = HMS_BLL.GetLabIdsBLL();
            txtlabid.ItemsSource = listofids;
            txtlabid.Text = "Select";
        }

        private void LoadRoomIds()
        {
            List<string> listofids = HMS_BLL.GetRoomIdsBLL();
            roomId.ItemsSource = listofids;
            roomId.Text = "Select";
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            InPatient newInPatient = new InPatient();
            try
            {
                newInPatient.PatientId = pId.Text;
                newInPatient.RoomId = roomId.Text;
                newInPatient.DoctorId = docId.Text;
                newInPatient.AdmissionDate = Convert.ToDateTime(txtadmdate.Text);
                newInPatient.DischargeDate = Convert.ToDateTime(txtdisdate.Text);
                newInPatient.LabId = txtlabid.Text;
                newInPatient.AmountPerDay = Convert.ToInt32(txtamt.Text);
                int inPatientInserted = HMS_BLL.AddInPatientBLL(newInPatient);
                if (inPatientInserted > 0)
                {
                    MessageBox.Show("Patient Record is added..!");
                    RefreshInPatient();
                    Clear();
                }
                else
                    throw new HMS_Exception.HMS_Exception("Patient record not added..!");
            }
            catch (HMS_Exception.HMS_Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void RefreshInPatient()
        {
            DataTable dtInPatient = HMS_BLL.GetAllInPatientsBLL();
            if (dtInPatient.Rows.Count > 0)
            {
                dgInPatient.DataContext = dtInPatient;
            }
            else
            {
                MessageBox.Show("No InPatient Details available");
            }
        }

        private void BtnSearch_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                InPatient inPatient = null;
                if (pId.Text == null)
                    MessageBox.Show("Enter the InPatient Id to Search..!");
                string pid = pId.Text;
                inPatient = HMS_BLL.SearchInPatientBLL(pid);
                if (inPatient != null)
                {
                    pId.Text = inPatient.PatientId;
                    pId.IsEnabled = false;
                    roomId.Text = inPatient.RoomId;
                    docId.Text = inPatient.DoctorId;
                    txtadmdate.Text = Convert.ToDateTime(inPatient.AdmissionDate).ToString();
                    txtdisdate.Text = Convert.ToDateTime(inPatient.DischargeDate).ToString();
                    txtlabid.Text = inPatient.LabId;
                    txtamt.Text = Convert.ToInt32(inPatient.AmountPerDay).ToString();
                }
                else
                {
                    throw new HMS_Exception.HMS_Exception("InPatient's Detail Is Not Available");
                }
            }
            catch (HMS_Exception.HMS_Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnUpdate_Click(object sender, RoutedEventArgs e)
        {
            InPatient newInPatient = new InPatient();
            try
            {
                newInPatient.PatientId = pId.Text;
                newInPatient.RoomId = roomId.Text;
                newInPatient.DoctorId = docId.Text;
                newInPatient.AdmissionDate = Convert.ToDateTime(txtadmdate.Text);
                newInPatient.DischargeDate = Convert.ToDateTime(txtdisdate.Text);
                newInPatient.LabId = txtlabid.Text;
                newInPatient.AmountPerDay = Convert.ToInt32(txtamt.Text);
                int updatedInPatientInserted = HMS_BLL.UpdateInPatientBLL(newInPatient);
                if (updatedInPatientInserted > 0)
                {
                    MessageBox.Show("InPatient's Detail Updated Successfully...!");
                    RefreshInPatient();
                    Clear();
                }
                else
                {
                    throw new HMS_Exception.HMS_Exception("InPatient's Details Not Updated..!");
                }
            }
            catch (HMS_Exception.HMS_Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            string delInPatient = pId.Text;
            try
            {
                if (delInPatient != null)
                {
                    MessageBoxResult result = MessageBox.Show("Do you want to delete the InPatient's Details?", "Hospital Management System", MessageBoxButton.YesNo, MessageBoxImage.Question);
                    if (result == MessageBoxResult.Yes)
                    {
                        int count = HMS_BLL.DeleteInPatientBLL(delInPatient);
                        if (count > 0)
                        {
                            MessageBox.Show("InPatient's Details Deleted Successfully..!");
                            RefreshInPatient();
                            Clear();
                        }
                    }
                    else
                        MessageBox.Show("InPatient's Detail Is Not Deleted..!");
                }
            }
            catch (HMS_Exception.HMS_Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnClear_Click(object sender, RoutedEventArgs e)
        {
            Clear();
            pId.Focus();
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Hide();
        }

        private void BtnRefresh_Click(object sender, RoutedEventArgs e)
        {
            Clear();
            RefreshInPatient();
            pId.IsEnabled = true;
        }

        private void BtnSearchDoctor_Click(object sender, RoutedEventArgs e)
        {
            RefreshInPatient();
            string docid = docId.SelectedValue.ToString();
            try
            {
                if (docId.Text == "Select")
                    MessageBox.Show("Enter Doctor Id to Search");
                DataSet dataSet = HMS_BLL.SearchInPatientByDoctorBLL(docid);
                dgInPatient.DataContext = dataSet.Tables["InPatient"];

            }
            catch (HMS_Exception.HMS_Exception ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private void BtnSearchRoom_Click(object sender, RoutedEventArgs e)
        {
            RefreshInPatient();
            string roomid = roomId.SelectedValue.ToString();
            try
            {
                if (roomId.Text == "Select")
                    MessageBox.Show("Enter Room Id to Search");
                DataSet dataSet = HMS_BLL.SearchInPatientByRoomBLL(roomid);
                dgInPatient.DataContext = dataSet.Tables["InPatient"];

            }
            catch (HMS_Exception.HMS_Exception ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}