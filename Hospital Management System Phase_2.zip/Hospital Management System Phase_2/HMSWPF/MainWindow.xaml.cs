﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace HMSWPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void BtnPatient_Click(object sender, RoutedEventArgs e)
        {
            PatientWPF patientWPf = new PatientWPF();
            patientWPf.Show();
            this.Hide();
        }

        private void BtnInPatient_Click(object sender, RoutedEventArgs e)
        {
            InPatientWPF inPatientWPF = new InPatientWPF();
            inPatientWPF.Show();
            this.Hide();
        }

        private void BtnOutPatient_Click(object sender, RoutedEventArgs e)
        {
            OutPatientWPF outPatientWPF = new OutPatientWPF();
            outPatientWPF.Show();
            this.Hide();
        }

        private void BtnLab_Click(object sender, RoutedEventArgs e)
        {
            LabWPF labWPF = new LabWPF();
            labWPF.Show();
            this.Hide();
        }

        private void BtnBill_Click(object sender, RoutedEventArgs e)
        {
            BillWPF billWPF = new BillWPF();
            billWPF.Show();
            this.Hide();
        }
    }
}
