﻿using HMS_BusinessLogic;
using HMS_Entities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace HMSWPF
{
    /// <summary>
    /// Interaction logic for PatientWPF.xaml
    /// </summary>
    public partial class PatientWPF : Window
    {
        public PatientWPF()
        {
            InitializeComponent();
            pGender.SelectedIndex = 0;
        }


        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            RefreshPatients();
            LoadDoctorIds();
        }

        private void LoadDoctorIds()
        {
            List<string> listofids = HMS_BLL.GetDoctorIdsBLL();
            dId.ItemsSource = listofids;
            dId.Text = "Select";
        }

        private void Clear()
        {
            pId.Text = "";
            pName.Text = "";
            pAge.Text = "";
            pWeight.Text = "";
            pGender.Text = "Select";
            pAddress.Text = "";
            pPhone.Text = "";
            pDisease.Text = "";
            dId.Text = "Select";
            pId.Focus();
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Hide();
        }

        private void BtnClear_Click(object sender, RoutedEventArgs e)
        {
            pId.Text = "";
            pName.Text = "";
            pAge.Text = "";
            pWeight.Text = "";
            pGender.Text = "";
            pAddress.Text = "";
            pPhone.Text = "";
            pDisease.Text = "";
            dId.Text = "";
            pId.Focus();
        }

        private void Add_Click(object sender, RoutedEventArgs e)
        {
            Patient newPatient = new Patient();
            try
            {
                newPatient.PatientId = pId.Text;
                newPatient.PatientName = pName.Text;
                newPatient.Age = int.Parse(pAge.Text);
                newPatient.Weight = int.Parse(pWeight.Text);
                newPatient.Gender = pGender.Text;
                newPatient.Address = pAddress.Text;
                newPatient.PhoneNo = pPhone.Text;
                newPatient.Disease = pDisease.Text;
                newPatient.DoctorId = dId.Text;
                int patientInserted = HMS_BLL.AddPatientBLL(newPatient);
                if (patientInserted > 0)
                {
                    MessageBox.Show("Patient Record is added..!");
                    RefreshPatients();
                    Clear();
                }
                else
                    throw new HMS_Exception.HMS_Exception("Patient record not added..!");
            }
            catch (HMS_Exception.HMS_Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Update_Click(object sender, RoutedEventArgs e)
        {
            Patient newPatient = new Patient();
            try
            {
                newPatient.PatientId = pId.Text;
                newPatient.PatientName = pName.Text;
                newPatient.Age = Convert.ToInt32(pAge.Text);
                newPatient.Weight = Convert.ToInt32(pWeight.Text);
                newPatient.Gender = pGender.Text;
                newPatient.Address = pAddress.Text;
                newPatient.PhoneNo = pPhone.Text;
                newPatient.Disease = pDisease.Text;
                newPatient.DoctorId = dId.Text;
                int updatedPatientInserted = HMS_BLL.UpdatePatientBLL(newPatient);
                if (updatedPatientInserted > 0)
                {
                    MessageBox.Show("Patient Details Updated Successfully...!");
                    RefreshPatients();
                    Clear();
                }
                else
                {
                    throw new HMS_Exception.HMS_Exception("Patient Details Not Updated..!");
                }
            }
            catch (HMS_Exception.HMS_Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Search_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Patient patient = null;
                if (pId.Text == null)
                    MessageBox.Show("Enter the Patient Id to Search..!");
                string pid = pId.Text;
                patient = HMS_BLL.SearchPatientBLL(pid);
                if (patient != null)
                {
                    pId.Text = patient.PatientId;
                    pId.IsEnabled = false;
                    pName.Text = patient.PatientName;
                    //pName.IsEnabled = false;
                    pAge.Text = patient.Age.ToString();
                    //pAge.IsEnabled = false;
                    pWeight.Text = patient.Weight.ToString();
                    //pWeight.IsEnabled = false;
                    pGender.Text = patient.Gender.ToString();
                    //pGender.IsEnabled = false;
                    pAddress.Text = patient.Address;
                    //pAddress.IsEnabled = false;
                    pPhone.Text = patient.PhoneNo;
                    //pPhone.IsEnabled = false;
                    pDisease.Text = patient.Disease;
                    //pDisease.IsEnabled = false;
                    dId.Text = patient.DoctorId;
                    //dId.IsEnabled = false;
                }
                else
                {
                    throw new HMS_Exception.HMS_Exception("Patient's Detail Is Not Available");
                }
            }
            catch (HMS_Exception.HMS_Exception ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private void SearchDoctor_Click(object sender, RoutedEventArgs e)
        {
            RefreshPatients();
            string pid = dId.SelectedValue.ToString();
            try
            {
                if (dId.Text == "Select")
                    MessageBox.Show("Enter Doctor Id to Search");
                DataSet dataSet = HMS_BLL.SearchPatientByDoctorBLL(pid);
                dgPatient.DataContext = dataSet.Tables["Patient"];

            }
            catch (HMS_Exception.HMS_Exception ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private void Delete_Click(object sender, RoutedEventArgs e)
        {
            string delPatient = pId.Text;
            try
            {
                if (delPatient != null)
                {
                    MessageBoxResult result = MessageBox.Show("Do you want to delete the Patient's Details?", "Hospital Management System", MessageBoxButton.YesNo, MessageBoxImage.Question);
                    if (result == MessageBoxResult.Yes)
                    {
                        int count = HMS_BLL.DeletePatientBLL(delPatient);
                        if (count > 0)
                        {
                            MessageBox.Show("Patient's Details Deleted Successfully..!");
                            RefreshPatients();
                            Clear();
                        }
                    }
                    else
                        MessageBox.Show("Patient's Detail Is Not Deleted..!");
                }
            }
            catch (HMS_Exception.HMS_Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void RefreshPatients()
        {
            DataTable dtPatient = HMS_BLL.GetAllPatientsBLL();
            if (dtPatient.Rows.Count > 0)
            {
                dgPatient.DataContext = dtPatient;
            }
            else
            {
                MessageBox.Show("No Patient Details available");
            }
        }

        private void BtnRefresh_Click(object sender, RoutedEventArgs e)
        {
            Clear();
            RefreshPatients();
            pId.IsEnabled = true;
        }

        private void DgPatient_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
