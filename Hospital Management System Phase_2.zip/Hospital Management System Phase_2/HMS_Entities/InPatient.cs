﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HMS_Entities
{
    [Serializable]
   public class InPatient
    {
        public string PatientId { get; set; }
        public string RoomId { get; set; }
        public string DoctorId { get; set; }
        public DateTime AdmissionDate { get; set; }
        public DateTime DischargeDate { get; set; }
        public string LabId { get; set; }
        public double AmountPerDay { get; set; }
    }
}
