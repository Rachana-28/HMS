﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using HMSEntities;
using HMSException;
using System.Configuration;


namespace HMSDAL
{
    public class Hospital_Dal
    {
        public bool AddPatientDAL(Patient objPatient)
        {
            bool patientAdded = false;
            SqlConnection Con = null;
            try
            {
                Con = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HMSConnectionString"].ConnectionString);
                SqlCommand Com = new SqlCommand("[46009517].InsertPatient", Con);
                Com.CommandType = CommandType.StoredProcedure;
                //
                SqlParameter objSqlParam_PatientId = new SqlParameter("@PatientId", objPatient.PatientId);
                SqlParameter objSqlParam_DoctorId = new SqlParameter("@DoctorId", objPatient.DoctorId);
                SqlParameter objSqlParam_PatientName = new SqlParameter("@PatientName", objPatient.PatientName);
                SqlParameter objSqlParam_PhoneNo = new SqlParameter("@PhoneNo", objPatient.PhoneNo);
                SqlParameter objSqlParam_Gender = new SqlParameter("@Gender", objPatient.Gender);
                SqlParameter objSqlParam_Age = new SqlParameter("@Age", objPatient.Age);
                SqlParameter objSqlParam_PWeight = new SqlParameter("@PWeight", objPatient.PWeight);
                SqlParameter objSqlParam_PAddress = new SqlParameter("@PAddress", objPatient.PAddress);
                SqlParameter objSqlParam_Disease = new SqlParameter("@Disease", objPatient.Disease);
                //
                Com.Parameters.Add(objSqlParam_PatientId);
                Com.Parameters.Add(objSqlParam_DoctorId);
                Com.Parameters.Add(objSqlParam_PatientName);
                Com.Parameters.Add(objSqlParam_PhoneNo);
                Com.Parameters.Add(objSqlParam_Gender);
                Com.Parameters.Add(objSqlParam_Age);
                Com.Parameters.Add(objSqlParam_PWeight);
                Com.Parameters.Add(objSqlParam_PAddress);
                Com.Parameters.Add(objSqlParam_Disease);

                //
                Con.Open();
                Com.ExecuteNonQuery();
                patientAdded = true;
            }
            catch (SqlException objSqlEx)
            {
                throw new Hospital_Exceptions(objSqlEx.Message);
            }
            finally
            {
                Con.Close();
            }
            return patientAdded;
        }
        public bool UpdatePatientDAL(Patient objPatient)
        {
            bool patientUpdated = false;
            SqlConnection Con = null;
            try
            {
                Con = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HMSConnectionString"].ConnectionString);
                SqlCommand Com = new SqlCommand("[46009517].UpdatePatient", Con);
                Com.CommandType = CommandType.StoredProcedure;
                //
                SqlParameter objSqlParam_PatientId = new SqlParameter("@PatientId", objPatient.PatientId);
                SqlParameter objSqlParam_DoctorId = new SqlParameter("@DoctorId", objPatient.DoctorId);
                SqlParameter objSqlParam_PatientName = new SqlParameter("@PatientName", objPatient.PatientName);
                SqlParameter objSqlParam_PhoneNo = new SqlParameter("@PhoneNo", objPatient.PhoneNo);
                SqlParameter objSqlParam_Gender = new SqlParameter("@Gender", objPatient.Gender);
                SqlParameter objSqlParam_Age = new SqlParameter("@Age", objPatient.Age);
                SqlParameter objSqlParam_PWeight = new SqlParameter("@PWeight", objPatient.PWeight);
                SqlParameter objSqlParam_PAddress = new SqlParameter("@PAddress", objPatient.PAddress);
                SqlParameter objSqlParam_Disease = new SqlParameter("@Disease", objPatient.Gender);
                //
                Com.Parameters.Add(objSqlParam_PatientId);
                Com.Parameters.Add(objSqlParam_DoctorId);
                Com.Parameters.Add(objSqlParam_PatientName);
                Com.Parameters.Add(objSqlParam_PhoneNo);
                Com.Parameters.Add(objSqlParam_Gender);
                Com.Parameters.Add(objSqlParam_Age);
                Com.Parameters.Add(objSqlParam_PWeight);
                Com.Parameters.Add(objSqlParam_PAddress);
                Com.Parameters.Add(objSqlParam_Disease);

                //
                Con.Open();
                Com.ExecuteNonQuery();
                patientUpdated = true;
            }
            catch (SqlException objSqlEx)
            {
                throw new Hospital_Exceptions(objSqlEx.Message);
            }
            finally
            {
                Con.Close();
            }
            return patientUpdated;
        }

        public bool DeletePatientDAL(string PatientId)
        {
            bool patientDeleted = false;
            SqlConnection Con = null;
            try
            {
                Con = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HMSConnectionString"].ConnectionString);
                SqlCommand Com = new SqlCommand("[46009517].DeletePatient", Con);
                Com.CommandType = CommandType.StoredProcedure;
                //
                SqlParameter objSqlParam_PatientId = new SqlParameter("@PatientId", PatientId);

                //
                Com.Parameters.Add(objSqlParam_PatientId);

                Con.Open();
                Com.ExecuteNonQuery();
                patientDeleted = true;
            }
            catch (SqlException objSqlEx)
            {
                throw new Hospital_Exceptions(objSqlEx.Message);
            }
            finally
            {
                Con.Close();
            }
            return patientDeleted;
        }

        public Patient SearchPatientbyPatientIdDAL(string PatientId)
        {
            Patient objPatient = null;
            SqlConnection Con = null;
            try
            {
                Con = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HMSConnectionString"].ConnectionString);
                SqlCommand Com = new SqlCommand("[46009517].SelectPatient", Con);
                Com.CommandType = CommandType.StoredProcedure;
                //
                SqlParameter objSqlParam_PatientId = new SqlParameter("@PatientId", SqlDbType.VarChar, 20);
                SqlParameter objSqlParam_DoctorId = new SqlParameter("@DoctorId", SqlDbType.VarChar, 20);
                SqlParameter objSqlParam_PatientName = new SqlParameter("@PatientName", SqlDbType.VarChar, 20);
                SqlParameter objSqlParam_PhoneNo = new SqlParameter("@PhoneNo", SqlDbType.VarChar, 20);
                SqlParameter objSqlParam_Gender = new SqlParameter("@Gender", SqlDbType.VarChar, 10);
                SqlParameter objSqlParam_Age = new SqlParameter("@Age", SqlDbType.Int);
                SqlParameter objSqlParam_PWeight = new SqlParameter("@PWeight", SqlDbType.Float);
                SqlParameter objSqlParam_PAddress = new SqlParameter("@PAddress", SqlDbType.VarChar, 100);
                SqlParameter objSqlParam_Disease = new SqlParameter("@Disease", SqlDbType.VarChar, 100);
                //
                objSqlParam_PatientId.Direction = ParameterDirection.Input;
                objSqlParam_DoctorId.Direction = ParameterDirection.Output;
                objSqlParam_PatientName.Direction = ParameterDirection.Output;
                objSqlParam_PhoneNo.Direction = ParameterDirection.Output;
                objSqlParam_Gender.Direction = ParameterDirection.Output;
                objSqlParam_Age.Direction = ParameterDirection.Output;
                objSqlParam_PWeight.Direction = ParameterDirection.Output;
                objSqlParam_PAddress.Direction = ParameterDirection.Output;
                objSqlParam_Disease.Direction = ParameterDirection.Output;



                //
                Com.Parameters.Add(objSqlParam_PatientId);
                Com.Parameters.Add(objSqlParam_DoctorId);
                Com.Parameters.Add(objSqlParam_PatientName);
                Com.Parameters.Add(objSqlParam_PhoneNo);
                Com.Parameters.Add(objSqlParam_Gender);
                Com.Parameters.Add(objSqlParam_Age);
                Com.Parameters.Add(objSqlParam_PWeight);
                Com.Parameters.Add(objSqlParam_PAddress);
                Com.Parameters.Add(objSqlParam_Disease);

                //
                objSqlParam_PatientId.Value = PatientId;
                //
                Con.Open();
                Com.ExecuteNonQuery();
                objPatient = new Patient();
                objPatient.PatientId = objSqlParam_PatientId.Value as string;
                objPatient.DoctorId = objSqlParam_DoctorId.Value as string;
                objPatient.PatientName = objSqlParam_PatientName.Value as string;
                objPatient.PhoneNo = objSqlParam_PhoneNo.Value as string;
                objPatient.Gender = objSqlParam_Gender.Value as string;
                objPatient.Age = Convert.ToInt16(objSqlParam_Age.Value);
                objPatient.PWeight = Convert.ToDouble(objSqlParam_PWeight.Value);
                objPatient.PAddress = objSqlParam_PAddress.Value as string;
                objPatient.Disease = objSqlParam_Disease.Value as string;
            }
            catch (SqlException objSqlEx)
            {
                throw new Hospital_Exceptions(objSqlEx.Message);
            }
            finally
            {
                Con.Close();
            }
            return objPatient;
        }
       
        public List<Patient> GetAllPatientsDAL()
        {
            List<Patient> Patients = new List<Patient>();
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HMSConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[46009517].ListPatient", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                objCon.Open();
                SqlDataReader objDR = objCom.ExecuteReader();
                while (objDR.Read())
                {
                    Patient objPatient = new Patient();
                    objPatient.PatientId = objDR[0] as string;
                    objPatient.PatientName = objDR[1] as string;
                    objPatient.Age = Convert.ToInt32(objDR[2]);
                    objPatient.PWeight = Convert.ToDouble(objDR[3]);
                    objPatient.Gender = objDR[4] as string;
                    objPatient.PAddress = objDR[5] as string;
                    objPatient.PhoneNo = objDR[6] as string;
                    objPatient.Disease = objDR[7] as string;
                    objPatient.DoctorId = objDR[8] as string;
                    
                    Patients.Add(objPatient);
                }
            }
            catch (SqlException objSqlEx)
            {
                throw new Hospital_Exceptions(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return Patients;
        }
    }
}
























        