﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using HMSDAL;
using HMSEntities;
using HMSException;


namespace HMSBAL
{
    public class Hospital_Bal
    {
        private static bool ValidatePatient(Patient patient)
        {
            StringBuilder sb = new StringBuilder();
            bool validPatient = true;
            if (patient.PatientId == string.Empty)
            {
                validPatient = false;
                sb.Append(Environment.NewLine
                    + "Patient can't  be empty");
            }
            if (patient.DoctorId == string.Empty)
            {
                validPatient = false;
                sb.Append(Environment.NewLine + "DoctorID  can't be empty.");
            }
            if (patient.PatientName == string.Empty)
            {
                validPatient = false;
                sb.Append(Environment.NewLine + "Patient name should start with Capital.");
            }
            if (patient.PhoneNo.Length < 0)
            {
                validPatient = false;
                sb.Append(Environment.NewLine + "Mobile number must be of 10 digits.");
            }
            else if (!Regex.IsMatch(patient.PhoneNo, "[6-9][0-9]{9}"))
            {
                sb.Append("Phone number should start with 6 or 7 or 8 or 9 and it should have exactly 10 digits\n");
                validPatient = false;
            }
            if (validPatient == false)
            {
                throw new Hospital_Exceptions(sb.ToString());
            }
            return validPatient;

        }

        private static bool ValidateAppointment(Appointment appointment)
        {
            StringBuilder sb = new StringBuilder();
            bool validAppointment = true;
            try
            {
                if (appointment.AppointmentId == string.Empty)
                {
                    sb.Append(Environment.NewLine + "Appointment Id is required cannnot be blank");
                    validAppointment = false;
                }
                if (appointment.PatientId == string.Empty)
                {
                    sb.Append(Environment.NewLine + "Patient Id is required cannnot be blank");
                    validAppointment = false;
                }
                if (validAppointment == false)
                    throw new Hospital_Exceptions(sb.ToString());
            }
            catch (Hospital_Exceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return validAppointment;
        }

        private static bool ValidateBill(BillGeneration bill)
        {
            StringBuilder sb = new StringBuilder();
            bool validBill = true;
            try
            {
                if (bill.BillId == string.Empty)
                {
                    sb.Append(Environment.NewLine + "Bill Id is required cannnot be blank");
                    validBill = false;
                }
                if (bill.PatientId == string.Empty)
                {
                    sb.Append(Environment.NewLine + "Patient Id is required cannnot be blank");
                    validBill = false;
                }
                else if (bill.PatientId == "Select")
                {
                    sb.Append(Environment.NewLine + "Patient Id is required");
                    validBill = false;
                }
                if (bill.DoctorId == string.Empty)
                {
                    sb.Append(Environment.NewLine + "Doctor Id is required cannnot be blank");
                    validBill = false;
                }
                else if (bill.DoctorId == "Select")
                {
                    sb.Append(Environment.NewLine + "Doctor Id is Required");
                    validBill = false;
                }
                if (validBill == false)
                    throw new Hospital_Exceptions(sb.ToString());
            }
            catch (Hospital_Exceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return validBill;
        }

        private static bool ValidateLab(LabReport lab)
        {
            StringBuilder sb = new StringBuilder();
            bool validLab = true;
            try
            {
                if (lab.LabId == string.Empty)
                {
                    sb.Append(Environment.NewLine + "Lab Id is required cannnot be blank");
                    validLab = false;
                }
                if (lab.PatientId == string.Empty)
                {
                    sb.Append(Environment.NewLine + "Patient Id is required cannnot be blank");
                    validLab = false;
                }
                else if (lab.PatientId == "Select")
                {
                    sb.Append(Environment.NewLine + "Patient Id is Required");
                    validLab = false;
                }
                if (lab.DoctorId == string.Empty)
                {
                    sb.Append(Environment.NewLine + "Doctor Id is required cannnot be blank");
                    validLab = false;
                }
                if (validLab == false)
                    throw new Hospital_Exceptions(sb.ToString());
            }
            catch (Hospital_Exceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return validLab;
        }

        private static bool ValidateInPatient(InPatient inPatient)
        {
            StringBuilder sb = new StringBuilder();
            bool validInPatient = true;
            try
            {
                if (inPatient.LabId == string.Empty)
                {
                    sb.Append(Environment.NewLine + "Lab Id is required cannnot be blank");
                    validInPatient = false;
                }
                else if (inPatient.LabId == "Select")
                {
                    sb.Append(Environment.NewLine + "Lab Id is Required");
                    validInPatient = false;
                }
                if (inPatient.PatientId == string.Empty)
                {
                    sb.Append(Environment.NewLine + "Patient Id is required cannnot be blank");
                    validInPatient = false;
                }
                if (inPatient.RoomNo == string.Empty)
                {
                    sb.Append(Environment.NewLine + "Room Id is required cannnot be blank");
                    validInPatient = false;
                }

                else if (inPatient.RoomNo == "Select")
                {
                    sb.Append(Environment.NewLine + "Room Id is Required");
                    validInPatient = false;
                }
                if (inPatient.DoctorId == string.Empty)
                {
                    sb.Append(Environment.NewLine + "Doctor Id is required cannnot be blank");
                    validInPatient = false;
                }
                else if (inPatient.DoctorId == "Select")
                {
                    sb.Append(Environment.NewLine + "Doctor Id is Required");
                    validInPatient = false;
                }
                if (inPatient.AdmissionDate == null)
                {
                    sb.Append(Environment.NewLine + "Admission Date is Required");
                    validInPatient = false;
                }
                if (inPatient.DischargeDate == null)
                {
                    sb.Append(Environment.NewLine + "Discharge Date is Required");
                    validInPatient = false;
                }
                if (inPatient.AmountPerDay <= 0)
                {
                    sb.Append(Environment.NewLine + "Enter the Amount Per Day");
                    validInPatient = false;
                }
                if (validInPatient == false)
                    throw new Hospital_Exceptions(sb.ToString());
            }
            catch (Hospital_Exceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return validInPatient;
        }

        private static bool ValidateOutPatient(OutPatient outPatient)
        {
            StringBuilder sb = new StringBuilder();
            bool validOutPatient = true;
            try
            {
                if (outPatient.LabId == string.Empty)
                {
                    sb.Append(Environment.NewLine + "Lab Id is required cannnot be blank");
                    validOutPatient = false;
                }
                else if (outPatient.LabId == "Select")
                {
                    sb.Append(Environment.NewLine + "Lab Id is Required");
                    validOutPatient = false;
                }
                if (outPatient.PatientId == string.Empty)
                {
                    sb.Append(Environment.NewLine + "Patient Id is required cannnot be blank");
                    validOutPatient = false;
                }
                if (outPatient.DoctorId == string.Empty)
                {
                    sb.Append(Environment.NewLine + "Doctor Id is required cannnot be blank");
                    validOutPatient = false;
                }
                else if (outPatient.DoctorId == "Select")
                {
                    sb.Append(Environment.NewLine + "Doctor Id is Required");
                    validOutPatient = false;
                }
                if (outPatient.TreatmentDate == null)
                {
                    sb.Append(Environment.NewLine + "Treatment Date is Required");
                    validOutPatient = false;
                }
                if (validOutPatient == false)
                    throw new Hospital_Exceptions(sb.ToString());
            }
            catch (Hospital_Exceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return validOutPatient;
        }

        public static bool AddPatientBAL(Patient patient)
        {
            bool patientAdded = false;
            try
            {
                if (ValidatePatient(patient))
                {
                    Hospital_Dal patientDAL = new Hospital_Dal();
                    patientAdded = patientDAL.AddPatientDAL(patient);
                    return patientAdded;
                }
            }
            catch (Hospital_Exceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return patientAdded;
        }

        public static bool UpdatePatientBAL(Patient patient)
        {
            bool patientUpdated = false;
            try
            {
                if (ValidatePatient(patient))
                {
                    Hospital_Dal patientDAL = new Hospital_Dal();
                    patientUpdated = patientDAL.UpdatePatientDAL(patient);
                    return patientUpdated;
                }
            }
            catch (Hospital_Exceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return patientUpdated;
        }

        public static bool DeletePatientBAL(string PatientId)
        {

            bool PatientDeleted = false;
            try
            {
                if (PatientId != null)
                {
                    Hospital_Dal patientDAL = new Hospital_Dal();

                    PatientDeleted = patientDAL.DeletePatientDAL(PatientId);
                }
                else
                {
                    throw new Hospital_Exceptions("Invalid OutPatient ID");
                }
            }
            catch (Hospital_Exceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return PatientDeleted;
        }

        public static Patient SearchPatientbyPatientIDBAL(string patientId)
        {
            Patient patient = null;
            try
            {
                if (patientId != null)
                {
                    Hospital_Dal patientDAL = new Hospital_Dal();
                    patient = patientDAL.SearchPatientbyPatientIdDAL(patientId); 
                }
                else
                {
                    throw new Hospital_Exceptions("Patient Id is Required.");
                }
            }
            catch (Hospital_Exceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return patient;
        }

        public static List<Patient> GetAllPatientBAL()
        {
            List<Patient> patientList;
            try
            {
                Hospital_Dal patient = new Hospital_Dal();
                patientList = patient.GetAllPatientsDAL();
            }
            catch (Hospital_Exceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return patientList;
        }

    }
}

    


    