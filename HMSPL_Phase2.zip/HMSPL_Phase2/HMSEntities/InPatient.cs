﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HMSEntities
{
   public class InPatient
    {
        public string PatientId { get; set; }
        public string RoomNo { get; set; }
        public string DoctorId { get; set; }
        public DateTime AdmissionDate { get; set; }
        public DateTime DischargeDate { get; set; }
        public string LabId { get; set; }
        public float AmountPerDay { get; set; }
    }
}



