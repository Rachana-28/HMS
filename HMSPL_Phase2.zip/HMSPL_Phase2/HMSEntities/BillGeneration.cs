﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HMSEntities
{
    public class BillGeneration
    {            
            public string BillId { get; set; }
            public string PatientId { get; set; }
            public string PatientType { get; set; }
            public string DoctorId { get; set; }
            public double DoctorFees { get; set; }
            public double RoomCharges { get; set; }
            public double OperationCharges { get; set; }
            public double MedicineFees { get; set; }
            public int TotalDays { get; set; }
            public double LabFees { get; set; }
            public double TotalAmount { get; set; }
        }
    }



