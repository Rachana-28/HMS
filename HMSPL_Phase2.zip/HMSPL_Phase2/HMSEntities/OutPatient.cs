﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HMSEntities
{
    public class OutPatient
    {
        public string PatientId { get; set; }
        public DateTime TreatmentDate { get; set; }
        public string DoctorId { get; set; }
        public string LabId { get; set; }

    }
}
