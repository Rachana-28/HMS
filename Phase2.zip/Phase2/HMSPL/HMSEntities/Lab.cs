﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HMSEntities
{
    public class Lab
    {
        public string LabNo { get; set; }
        public string PatientID { get; set; }
        public string DoctorID { get; set; }
        public DateTime TestDate { get; set; }
        public string TestType { get; set; }
        public string PatientType { get; set; }
    }
}
