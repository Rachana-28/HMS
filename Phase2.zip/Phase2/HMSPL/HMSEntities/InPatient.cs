﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HMSEntities
{
    public class InPatient
    {
        public string PatientID { get; set; }
        public string RoomNo { get; set; }
        public string DoctorID { get; set; }
        public DateTime AdmissionDate { get; set; }
        public DateTime DischargeDate { get; set; }
        public string LabNo { get; set; }
        public double Amount { get; set; }
    }
}
