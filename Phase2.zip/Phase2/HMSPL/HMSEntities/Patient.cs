﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HMSEntities
{
   public class Patient
    {
        public string PatientID { get; set; }
        public string DoctorID { get; set; }
        public string PatientName { get; set; }
        public string MobileNo { get; set; }
        public string Gender { get; set; }
        public int Age { get; set; }
        public string PatientAddress { get; set; }
        public double PatientWeight { get; set; }
        public string Disease { get; set; }
        public string Lab_No { get; set; }
    }
}
