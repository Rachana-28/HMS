﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;
using HMSBal;
using HMSEntities;
using HMSExceptions;

namespace HMS_WPF
{
    /// <summary>
    /// Interaction logic for InPatient.xaml
    /// </summary>
    public partial class WPFInPatient : Window
    {
        public WPFInPatient()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            GetDoctor();
            GetLab();
            GetRoom();
        }

        private void GetDoctor()
        {
            try
            {
                DataTable doctorList = HMS_BAL.GetDoctorBAL();
                docId.ItemsSource = doctorList.DefaultView;
                docId.DisplayMemberPath = doctorList.Columns[0].ColumnName;
                docId.SelectedValuePath = doctorList.Columns[0].ColumnName;
            }
            catch (HMS_Exceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void GetLab()
        {
            try
            {
                DataTable labList = HMS_BAL.GetLabBAL();
                txtlabid.ItemsSource = labList.DefaultView;
                txtlabid.DisplayMemberPath = labList.Columns[0].ColumnName;
                txtlabid.SelectedValuePath = labList.Columns[0].ColumnName;
            }
            catch (HMS_Exceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void GetRoom()
        {
            try
            {
                DataTable roomList = HMS_BAL.GetRoomBAL();
                roomId.ItemsSource = roomList.DefaultView;
                roomId.DisplayMemberPath = roomList.Columns[0].ColumnName;
                roomId.SelectedValuePath = roomList.Columns[0].ColumnName;
            }
            catch (HMS_Exceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnSearchID_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string PatientId;
                InPatient objPatient;
                PatientId = pId.Text;
                objPatient = HMS_BAL.SearchInPatientbyPatientIDBAL(PatientId);
                if (objPatient != null)
                {
                    roomId.Text = objPatient.RoomNo;
                    docId.Text = objPatient.DoctorID;
                    txtadmdate.Text = Convert.ToDateTime(objPatient.AdmissionDate).ToString();
                    txtdisdate.Text = Convert.ToDateTime(objPatient.DischargeDate).ToString();
                    txtlabid.Text = objPatient.LabNo;
                    txtamt.Text = Convert.ToDouble(objPatient.Amount).ToString();

                }

                else
                {
                    MessageBox.Show("Patient record couldn't be found.");
                }
            }
            catch (HMS_Exceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                InPatient patient = new InPatient();
                if (pId.Text == string.Empty || roomId.Text == string.Empty || docId.Text == string.Empty || txtadmdate.Text == string.Empty || txtdisdate.Text == string.Empty ||
                   txtlabid.Text == string.Empty || txtamt.Text == string.Empty)
                {
                    MessageBox.Show("All Fields are required");
                }
                else
                {
                    bool InpatientAdded;
                    patient.PatientID = pId.Text;
                    patient.RoomNo = roomId.Text;
                    patient.DoctorID = docId.Text;
                    patient.AdmissionDate = Convert.ToDateTime(txtadmdate.Text);
                    patient.DischargeDate = Convert.ToDateTime(txtdisdate.Text);
                    patient.LabNo = txtlabid.Text;
                    patient.Amount = Convert.ToDouble(txtamt.Text);
                    InpatientAdded = HMS_BAL.AddInPatientBAL(patient);
                    if (InpatientAdded == true)
                    {
                        MessageBox.Show("InPatient added successfully");
                    }
                    else
                    {
                        MessageBox.Show("InPatient not added successfully");
                    }
                }

            }
            catch (HMS_Exceptions ex)
            {
                MessageBox.Show(ex.Message);
            }


        }

        private void BtnUpdate_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                InPatient patient = new InPatient();
                if (pId.Text == string.Empty || roomId.Text == string.Empty || docId.Text == string.Empty || txtadmdate.Text == string.Empty || txtdisdate.Text == string.Empty ||
                                   txtlabid.Text == string.Empty || txtamt.Text == string.Empty)
                {
                    MessageBox.Show("All Fields are required");
                }
                else
                {
                    bool InpatientUpdated;
                    patient.PatientID = pId.Text;
                    patient.RoomNo = roomId.Text;
                    patient.DoctorID = docId.Text;
                    patient.AdmissionDate = Convert.ToDateTime(txtadmdate.Text);
                    patient.DischargeDate = Convert.ToDateTime(txtdisdate.Text);
                    patient.LabNo = txtlabid.Text;
                    patient.Amount = Convert.ToDouble(txtamt.Text);
                    InpatientUpdated = HMS_BAL.UpdateInPatientBAL(patient);
                    if (InpatientUpdated == true)
                    {
                        MessageBox.Show("InPatient updated successfully");
                    }
                    else
                    {
                        MessageBox.Show("InPatient  could not updated ");
                    }
                }

            }
            catch (HMS_Exceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

       

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            string patientID;
            InPatient patient = new InPatient();
            try
            {

                if (pId.Text == string.Empty)
                {
                    MessageBox.Show("ID is Required");
                }
                else
                {
                    bool patientDeleted;
                    //
                    patientID = pId.Text;
                    //
                    patientDeleted = HMS_BAL.DeleteInPatientBAL(patientID);
                    if (patientDeleted == true)
                    {
                        MessageBox.Show("Patient record deleted successfully.");
                    }
                    else
                    {
                        MessageBox.Show("Patient record couldn't be deleted.");
                    }
                }
            }
            catch (HMS_Exceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        private void BtnClear_Click_1(object sender, RoutedEventArgs e)
        {
            Clear();

        }
        public void Clear()
        {
            pId.Clear();
            roomId.SelectedValue = -1;
            docId.SelectedValue = -1;
            txtadmdate.Text = "";
            txtdisdate.Text = "";
            txtlabid.SelectedValue = -1;
            txtamt.Clear();

        }


        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            Menu obj = new Menu();
            obj.Show();
            Close();
        }

        private void BtnRefresh_Click(object sender, RoutedEventArgs e)
        {
            Clear();
            RefreshInPatient();

        }
        private void RefreshInPatient()
        {
            List<InPatient> inPatients = null;
            inPatients = HMS_BAL.GetAllInPatientBAL();
            if (inPatients.Count > 0)
            {
                dgInPatient.DataContext = inPatients;
            }
            else
            {
                MessageBox.Show("No InPatient Details available");
            }
        }

        private void BtnGet_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                List<InPatient> objPatients = HMS_BAL.GetAllInPatientBAL();
                if (objPatients != null)
                {
                    dgInPatient.ItemsSource = objPatients;
                }
                else
                {
                    MessageBox.Show("No records available.");
                }
            }
            catch (HMS_Exceptions ex)
            {

                MessageBox.Show(ex.Message);
            }
        }
    }
 }


