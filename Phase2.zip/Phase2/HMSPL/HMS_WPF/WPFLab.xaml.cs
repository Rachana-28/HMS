﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;
using HMSBal;
using HMSEntities;
using HMSExceptions;

namespace HMS_WPF
{
    /// <summary>
    /// Interaction logic for Lab.xaml
    /// </summary>
    public partial class WPFLab : Window
    {
        public WPFLab()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            GetDoctor();
         
         
        }

        private void Btn_Add_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Lab lab = new Lab();
                if (lbLabId.Text == string.Empty || lpId.Text == string.Empty || cmbId.Text == string.Empty || lTestDate.Text == string.Empty || lTestType.Text == string.Empty || lblPatientType.Text == string.Empty
                   )
                {
                    MessageBox.Show("All Fields are required");
                }
                else
                {
                    bool LabAdded;
                    lab.LabNo = lbLabId.Text;
                    lab.PatientID = lpId.Text;
                    lab.DoctorID = cmbId.Text;
                    lab.TestDate = Convert.ToDateTime(lTestDate.Text);
                    lab.TestType = lTestType.Text;
                    lab.PatientType = lblPatientType.Text;


                    LabAdded = HMS_BAL.AddLabBAL(lab);
                    if (LabAdded == true)
                    {
                        MessageBox.Show("Lab Added successfully");
                    }
                    else
                    {
                        MessageBox.Show("Lab couldn't be Added ");
                    }
                }

            }
            catch (HMS_Exceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Btn_Update_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Lab lab = new Lab();
                if (lbLabId.Text == string.Empty || lpId.Text == string.Empty || cmbId.Text == string.Empty || lTestDate.Text == string.Empty || lTestType.Text == string.Empty || lblPatientType.Text == string.Empty
                   )
                {
                    MessageBox.Show("All Fields are required");
                }
                else
                {
                    bool LabUpadted;
                    lab.LabNo = lbLabId.Text;
                    lab.PatientID = lpId.Text;
                    lab.DoctorID = cmbId.Text;
                    lab.TestDate = Convert.ToDateTime(lTestDate.Text);
                    lab.TestType = lTestType.Text;
                    lab.PatientType = lblPatientType.Text;


                    LabUpadted = HMS_BAL.UpdateLabBAL(lab);
                    if (LabUpadted == true)
                    {
                        MessageBox.Show("Lab Upadted successfully");
                    }
                    else
                    {
                        MessageBox.Show("Lab couldn't be  updated");
                    }
                }

            }
            catch (HMS_Exceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    
        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            string LabId;
            Lab lab = new Lab();
            try
            {

                if (lbLabId.Text == string.Empty)
                {
                    MessageBox.Show("ID is Required");
                }
                else
                {
                    bool patientDeleted;
                    //
                    LabId = lbLabId.Text;
                    //
                    patientDeleted = HMS_BAL.DeleteLabBAL(LabId);
                    if (patientDeleted == true)
                    {
                        MessageBox.Show("Patient record deleted successfully.");
                    }
                    else
                    {
                        MessageBox.Show("Patient record couldn't be deleted.");
                    }
                }
            }
            catch (HMS_Exceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Btn_Clear_Click(object sender, RoutedEventArgs e)
        {
            Clear();
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            Menu obj = new Menu();
            obj.Show();
            Close();
        }

        private void Btn_Refresh_Click(object sender, RoutedEventArgs e)
        {
            Clear();
            RefreshLab();

        }


        public void Clear()
        {
            lbLabId.Text = "";
            lTestDate.Text = "";
            cmbId.SelectedValue = -1;
            lpId.Text = "";
            lTestType.Clear();
            lblPatientType.Clear();

        }
        private void GetDoctor()
        {
            try
            {
                DataTable doctorList = HMS_BAL.GetDoctorBAL();
                cmbId.ItemsSource = doctorList.DefaultView;
                cmbId.DisplayMemberPath = doctorList.Columns[0].ColumnName;
                cmbId.SelectedValuePath = doctorList.Columns[0].ColumnName;
            }
            catch (HMS_Exceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        
        private void RefreshLab()
        {
            List<Lab> labs = null;
            labs = HMS_BAL.GetAllLabsBAL();
            if (labs.Count > 0)
            {
                dgLabReport.DataContext = labs;
            }
            else
            {
                MessageBox.Show("No Lab Details available");
            }
        }

        private void BtnGet_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                List<Lab> objLabs = HMS_BAL.GetAllLabsBAL();
                if (objLabs != null)
                {
                    dgLabReport.ItemsSource = objLabs;
                }
                else
                {
                    MessageBox.Show("No records available.");
                }
            }
            catch (HMS_Exceptions ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        private void BtnSearchby_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string LabId;
                Lab objPatient;
                LabId = lbLabId.Text;
                objPatient = HMS_BAL.SearchLabbyPatientIDBAL(LabId);
                if (objPatient != null)
                {
                    lpId.Text = objPatient.PatientID;
                    cmbId.Text = objPatient.DoctorID;                  
                    lTestDate.Text = Convert.ToDateTime(objPatient.TestDate).ToString();
                    lTestType.Text = objPatient.TestType;
                    lblPatientType.Text = objPatient.PatientType;

                }

                else
                {
                    MessageBox.Show("Patient record couldn't be found.");
                }
            }
            catch (HMS_Exceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
