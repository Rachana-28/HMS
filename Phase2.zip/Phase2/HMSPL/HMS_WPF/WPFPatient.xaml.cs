﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using HMSBal;
using HMSEntities;
using HMSExceptions;
using System.Data;

namespace HMS_WPF
{
      public partial class WPFPatient : Window
    {
        public WPFPatient()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            GetDoctor();
        }
         private void GetDoctor()
        {
            try
            {
                DataTable doctorList = HMS_BAL.GetDoctorBAL();
                dId.ItemsSource = doctorList.DefaultView;
                dId.DisplayMemberPath = doctorList.Columns[0].ColumnName;
                dId.SelectedValuePath = doctorList.Columns[0].ColumnName;
            }
            catch (HMS_Exceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Add_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Patient objPatient = new Patient();




                if (pId.Text == string.Empty || dId.Text == string.Empty || pName.Text == string.Empty || pPhone.Text == string.Empty ||
                    pGender.Text == string.Empty || pAge.Text == string.Empty || pWeight.Text == string.Empty || pAddress.Text == string.Empty || pDisease.Text == string.Empty)
                {
                    MessageBox.Show("All Fields are required");
                }
                else
                {

                    bool RecordAdded;
                    objPatient.PatientID = pId.Text;
                    objPatient.DoctorID = dId.Text;
                    objPatient.PatientName = pName.Text;
                    objPatient.MobileNo = pPhone.Text;
                    objPatient.Gender = pGender.Text.ToString();
                    objPatient.Age = int.Parse(pAge.Text);
                    objPatient.PatientWeight = float.Parse(pWeight.Text);
                    objPatient.PatientAddress = pAddress.Text;
                    objPatient.Disease = pDisease.Text;



                    RecordAdded = HMS_BAL.AddPatientBAL(objPatient);
                    if (RecordAdded == true)
                    {
                        MessageBox.Show("Patient record added successfully.");
                    }
                    else
                    {
                        MessageBox.Show("Patient record couldn't be added.");
                    }
                }
            }
            catch (HMS_Exceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Update_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Patient objPatient = new Patient();




                if (pId.Text == string.Empty || dId.Text == string.Empty || pName.Text == string.Empty || pPhone.Text == string.Empty ||
                    pGender.Text == string.Empty || pAge.Text == string.Empty || pWeight.Text == string.Empty ||pAddress.Text == string.Empty || pDisease.Text == string.Empty)
                {
                    MessageBox.Show("All Fields are required");
                }
                else
                {

                    bool RecordUpdated;

                    objPatient.PatientID = pId.Text;
                    objPatient.DoctorID = dId.Text;
                    objPatient.PatientName = pName.Text;
                    objPatient.MobileNo = pPhone.Text;
                    objPatient.Gender = pGender.Text;
                    objPatient.Age = int.Parse(pAge.Text);
                    objPatient.PatientWeight = double.Parse(pWeight.Text);
                    objPatient.PatientAddress = pAddress.Text;
                    objPatient.Disease = pDisease.Text;



                    RecordUpdated = HMS_BAL.UpdatePatientBAL(objPatient);
                    if (RecordUpdated == true)
                    {
                        MessageBox.Show("Patient record updated successfully.");
                    }
                    else
                    {
                        MessageBox.Show("Patient record couldn't be updated.");
                    }
                }
            }
            catch (HMS_Exceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Search_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                List<Patient> objPatients = HMS_BAL.GetAllPatientBAL();
                if (objPatients != null)
                {
                    dgPatient.ItemsSource = objPatients;
                }
                else
                {
                    MessageBox.Show("No records available.");
                }
            }
            catch (HMS_Exceptions ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        private void Delete_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string PatientId;
                //
                bool patientDeleted;
                //
                PatientId = pId.Text;
                //
                patientDeleted = HMS_BAL.DeletePatientBAL(PatientId);
                if (patientDeleted == true)
                {
                    MessageBox.Show("Patient record deleted successfully.");
                }
                else
                {
                    MessageBox.Show("Patient record couldn't be deleted.");
                }
            }
            catch (HMS_Exceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
        }        

        private void BtnClear_Click(object sender, RoutedEventArgs e)
        {
            pId.Clear();
            //dId.Clear();
           pName.Clear();
           pPhone.Clear();
            pGender.SelectedIndex = -1;
            pAge.Clear();
          pWeight.Clear();
            pAddress.Clear();
           pDisease.Clear();
            dgPatient.DataContext = null;
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            Menu obj = new Menu();
            obj.Show();
            Close();
        }

        private void BtnRefresh_Click(object sender, RoutedEventArgs e)
        {
            List<Patient> outPatients = null;
            outPatients = HMS_BAL.GetAllPatientBAL();
            if (outPatients.Count > 0)
            {
                dgPatient.DataContext = outPatients;
            }
            else
            {
                MessageBox.Show("No OutPatient Details available");
            }
        }

        private void SearchID_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string PatientId;
                Patient objPatient;
                PatientId = pId.Text;
                objPatient = HMS_BAL.SearchPatientbyPatientIDBAL(PatientId);
                if (objPatient != null)
                {
                    dId.Text = objPatient.DoctorID;
                    pName.Text = objPatient.PatientName;
                    pPhone.Text = objPatient.MobileNo;
                    pGender.Text = objPatient.Gender;
                   pAge.Text = Convert.ToInt32(objPatient.Age).ToString();
                    pWeight.Text = Convert.ToDouble(objPatient.PatientWeight).ToString();
                    pAddress.Text = objPatient.PatientAddress;
                   pDisease.Text = objPatient.Disease;
                }

                else
                {
                    MessageBox.Show("Patient record couldn't be found.");
                }
            }
            catch (HMS_Exceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
