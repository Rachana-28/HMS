﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;
using HMSBal;
using HMSEntities;
using HMSExceptions;

namespace HMS_WPF
{
    
    public partial class WPFBill : Window
    {
        public WPFBill()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            GetDoctor();
            GetPatient();
        }

        private void GetDoctor()
        {
            try
            {
                DataTable doctorList = HMS_BAL.GetDoctorBAL();
                bdId.ItemsSource = doctorList.DefaultView;
                bdId.DisplayMemberPath = doctorList.Columns[0].ColumnName;
                bdId.SelectedValuePath = doctorList.Columns[0].ColumnName;
            }
            catch (HMS_Exceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void GetPatient()
        {
            try
            {
                DataTable patientList = HMS_BAL.GetPatientBAL();
                bpId.ItemsSource = patientList.DefaultView;
                bpId.DisplayMemberPath = patientList.Columns[0].ColumnName;
                bpId.SelectedValuePath = patientList.Columns[0].ColumnName;
            }
            catch (HMS_Exceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Bill bill = new Bill();
                if (bbillId.Text == string.Empty || bpId.Text == string.Empty || bpatientType.Text == string.Empty || bdId.Text == string.Empty || bDoctorFees.Text == string.Empty || bRoomCharges.Text == string.Empty ||
                   bOprtnCharges.Text == string.Empty || bMedBill.Text == string.Empty ||
                   bTotalDays.Text == string.Empty || bLabFees.Text == string.Empty || btotalamount.Text == string.Empty)
                {
                    MessageBox.Show("All Fields are required");
                }
                else
                {
                    bool BillAdded;
                    bill.BillID = bbillId.Text;
                    bill.PatientID = bpId.Text;
                    bill.PatientType = bpatientType.Text;
                    bill.DoctorID = bdId.Text;
                    bill.DoctorFees = Convert.ToDouble(bDoctorFees.Text);
                    bill.RoomCharges = Convert.ToDouble(bRoomCharges.Text);
                    bill.OperationCharges = Convert.ToDouble(bOprtnCharges.Text);
                    bill.MedicineFees = Convert.ToDouble(bMedBill.Text);
                    bill.TotalDays = Convert.ToInt32(bTotalDays.Text);
                    bill.LabFees = Convert.ToDouble(bLabFees.Text);
                    bill.TotalAmount = Convert.ToDouble(btotalamount.Text);
                    BillAdded = HMS_BAL.AddBillBAL(bill);
                    if (BillAdded == true)
                    {
                        MessageBox.Show("Bill added successfully");
                    }
                    else
                    {
                        MessageBox.Show("Bill not added successfully");
                    }
                }

            }
            catch (HMS_Exceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnUpdate_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Bill bill = new Bill();
                if (bbillId.Text == string.Empty || bpId.Text == string.Empty || bpatientType.Text == string.Empty || bdId.Text == string.Empty || bDoctorFees.Text == string.Empty || bRoomCharges.Text == string.Empty ||
                   bOprtnCharges.Text == string.Empty || bMedBill.Text == string.Empty || bTotalDays.Text == string.Empty || bLabFees.Text == string.Empty || btotalamount.Text == string.Empty)
                {
                    MessageBox.Show("All Fields are required");
                }
                else
                {
                    bool BillUpdated;
                    bill.BillID = bbillId.Text;
                    bill.PatientID = bpId.Text;
                    bill.PatientType = bpatientType.Text;
                    bill.DoctorID = bdId.Text;
                    bill.DoctorFees = Convert.ToDouble(bDoctorFees.Text);
                    bill.RoomCharges = Convert.ToDouble(bRoomCharges.Text);
                    bill.OperationCharges = Convert.ToDouble(bOprtnCharges.Text);
                    bill.MedicineFees = Convert.ToDouble(bMedBill.Text);
                    bill.TotalDays = Convert.ToInt32(bTotalDays.Text);
                    bill.LabFees = Convert.ToDouble(bLabFees.Text);
                    bill.TotalAmount = Convert.ToDouble(btotalamount.Text);
                    BillUpdated = HMS_BAL.UpdateBillBAL(bill);
                    if (BillUpdated == true)
                    {
                        MessageBox.Show("Bill updated successfully");
                    }
                    else
                    {
                        MessageBox.Show("InPatient couldn't be updated");
                    }
                }

            }
            catch (HMS_Exceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnSearch_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string BillId;
                Bill objBill;
                BillId = bbillId.Text;
                objBill = HMS_BAL.SearchBillbyBillIDBAL(BillId);
                if (objBill != null)
                {
                    bpId.Text = objBill.PatientID;
                    bpatientType.Text = objBill.PatientType;
                    bdId.Text = objBill.DoctorID;
                    bDoctorFees.Text = Convert.ToDouble(objBill.DoctorFees).ToString();
                    bRoomCharges.Text = Convert.ToDouble(objBill.RoomCharges).ToString();
                    bOprtnCharges.Text = Convert.ToDouble(objBill.OperationCharges).ToString();
                    bMedBill.Text = Convert.ToDouble(objBill.MedicineFees).ToString();
                    bTotalDays.Text = Convert.ToInt32(objBill.TotalDays).ToString();
                    bLabFees.Text = Convert.ToDouble(objBill.LabFees).ToString();
                    btotalamount.Text = Convert.ToDouble(objBill.TotalAmount).ToString();

                }

                else
                {
                    MessageBox.Show("Bill record couldn't be found.");
                }
            }
            catch (HMS_Exceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            string billID;
            Bill patient = new Bill();
            try
            {

                if (bbillId.Text == string.Empty)
                {
                    MessageBox.Show("ID is Required");
                }
                else
                {
                    bool billDeleted;
                    //
                    billID = bbillId.Text;
                    //
                    billDeleted = HMS_BAL.DeleteBillBAL(billID);
                    if (billDeleted == true)
                    {
                        MessageBox.Show("Bill record deleted successfully.");
                    }
                    else
                    {
                        MessageBox.Show("Bill record couldn't be deleted.");
                    }
                }
            }
            catch (HMS_Exceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnClear_Click(object sender, RoutedEventArgs e)
        {
        Clear();
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            Menu obj = new Menu();
            obj.Show();
            Close();
        }

        private void BtnRefresh_Click(object sender, RoutedEventArgs e)
        {
        Clear();
        RefreshInPatient();

    }
    private void RefreshInPatient()
    {
        List<Bill> bills = null;
        bills = HMS_BAL.GetAllBillsBAL();
        if (bills.Count > 0)
        {
            dgBill.DataContext = bills;
        }
        else
        {
            MessageBox.Show("No InPatient Details available");
        }
    }
    public void Clear()
    {
            bbillId.Clear();
            bpId.SelectedValue = -1;
            bpatientType.Clear();
            bdId.SelectedValue = -1;
            bDoctorFees.Clear();
            bRoomCharges.Clear();
            bLabFees.Clear();
            bOprtnCharges.Clear();
            bMedBill.Clear();
            bTotalDays.Clear();
            btotalamount.Clear();

    }


        private void BtnGetBill_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                List<Bill> objBills = HMS_BAL.GetAllBillsBAL();
                if (objBills != null)
                {
                    dgBill.ItemsSource = objBills;
                }
                else
                {
                    MessageBox.Show("No records available.");
                }
            }
            catch (HMS_Exceptions ex)
            {

                MessageBox.Show(ex.Message);
            }
        }
    }
}
