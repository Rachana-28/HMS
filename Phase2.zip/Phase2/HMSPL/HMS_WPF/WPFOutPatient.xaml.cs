﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;
using HMSBal;
using HMSEntities;
using HMSExceptions;

namespace HMS_WPF
{
    /// <summary>
    /// Interaction logic for OutPatient.xaml
    /// </summary>
    public partial class WPFOutPatient : Window
    {
        public WPFOutPatient()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            GetDoctor();
            GetLab();
        }
        public void Clear()
        {
            pId.Clear();
            txttreatmentdate.Text = "";
            docId.SelectedValue = -1;
            labid.SelectedValue = -1;

        }
        private void GetDoctor()
        {
            try
            {
                DataTable doctorList = HMS_BAL.GetDoctorBAL();
                docId.ItemsSource = doctorList.DefaultView;
                docId.DisplayMemberPath = doctorList.Columns[0].ColumnName;
                docId.SelectedValuePath = doctorList.Columns[0].ColumnName;
            }
            catch (HMS_Exceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void GetLab()
        {
            try
            {
                DataTable labList = HMS_BAL.GetLabBAL();
                labid.ItemsSource = labList.DefaultView;
                labid.DisplayMemberPath = labList.Columns[0].ColumnName;
                labid.SelectedValuePath = labList.Columns[0].ColumnName;
            }
            catch (HMS_Exceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void RefreshOutPatient()
        {
            List<OutPatient> outPatients = null;
            outPatients = HMS_BAL.GetAllOutPatientBAL();
            if (outPatients.Count > 0)
            {
                dgOutPatient.DataContext = outPatients;
            }
            else
            {
                MessageBox.Show("No OutPatient Details available");
            }
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                OutPatient patient = new OutPatient();
                if (pId.Text == string.Empty || txttreatmentdate.Text == string.Empty || docId.Text == string.Empty ||
                   labid.Text == string.Empty)
                {
                    MessageBox.Show("All Fields are required");
                }
                else
                {
                    bool OutpatientAdded;
                    patient.PatientID = pId.Text;
                    patient.TreatmentDate = Convert.ToDateTime(txttreatmentdate.Text);
                    patient.DoctorID = docId.Text;
                    patient.LabNo = labid.Text;

                    OutpatientAdded = HMS_BAL.AddOutPatientBAL(patient);
                    if (OutpatientAdded == true)
                    {
                        MessageBox.Show("OutPatient added successfully");
                    }
                    else
                    {
                        MessageBox.Show("OutPatient not added successfully");
                    }
                }

            }
            catch (HMS_Exceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnUpdate_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                OutPatient patient = new OutPatient();
                if (pId.Text == string.Empty || txttreatmentdate.Text == string.Empty || docId.Text == string.Empty ||
                   labid.Text == string.Empty)
                {
                    MessageBox.Show("All Fields are required");
                }
                else
                {
                    bool OutpatientUpdatedd;
                    patient.PatientID = pId.Text;
                    patient.TreatmentDate = Convert.ToDateTime(txttreatmentdate.Text);
                    patient.DoctorID = docId.Text;
                    patient.LabNo = labid.Text;

                    OutpatientUpdatedd = HMS_BAL.UpdateOutPatientBAL(patient);
                    if (OutpatientUpdatedd == true)
                    {
                        MessageBox.Show("OutPatient updated successfully");
                    }
                    else
                    {
                        MessageBox.Show("OutPatient couldn't be updated ");
                    }
                }

            }
            catch (HMS_Exceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnSearch_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            string patientID;
            OutPatient patient = new OutPatient();
            try
            {

                if (pId.Text == string.Empty)
                {
                    MessageBox.Show("ID is Required");
                }
                else
                {
                    bool patientDeleted;
                    //
                    patientID = pId.Text;
                    //
                    patientDeleted = HMS_BAL.DeleteOutPatientBAL(patientID);
                    if (patientDeleted == true)
                    {
                        MessageBox.Show("Patient record deleted successfully.");
                    }
                    else
                    {
                        MessageBox.Show("Patient record couldn't be deleted.");
                    }
                }
            }
            catch (HMS_Exceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

      

        private void BtnClear_Click(object sender, RoutedEventArgs e)
        {
            Clear();
        }

       

        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            Menu obj = new Menu();
            obj.Show();
            Close();
        }

        private void BtnRefresh_Click(object sender, RoutedEventArgs e)
        {
            Clear();
            RefreshOutPatient();
        }

        private void BtnSearchID_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string PatientId;
                OutPatient objPatient;
                PatientId = pId.Text;
                objPatient = HMS_BAL.SearchOutPatientbyPatientIDBAL(PatientId);
                if (objPatient != null)
                {
                    txttreatmentdate.Text = Convert.ToDateTime(objPatient.TreatmentDate).ToString();
                    docId.Text = objPatient.DoctorID;


                  labid.Text = objPatient.LabNo;


                }

                else
                {
                    MessageBox.Show("Patient record couldn't be found.");
                }
            }
            catch (HMS_Exceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnGet_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                List<OutPatient> objPatients = HMS_BAL.GetAllOutPatientBAL();
                if (objPatients != null)
                {
                    dgOutPatient.ItemsSource = objPatients;
                }
                else
                {
                    MessageBox.Show("No records available.");
                }
            }
            catch (HMS_Exceptions ex)
            {

                MessageBox.Show(ex.Message);
            }
        }
    }
}
