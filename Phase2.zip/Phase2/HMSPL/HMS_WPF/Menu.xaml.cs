﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace HMS_WPF
{
    /// <summary>
    /// Interaction logic for Menu.xaml
    /// </summary>
    public partial class Menu : Window
    {
        public Menu()
        {
            InitializeComponent();
        }

        private void BtnPatient_Click(object sender, RoutedEventArgs e)
        {
            WPFPatient obj = new WPFPatient();
            obj.Show();
            Close();
        }

        private void BtnInPatient_Click(object sender, RoutedEventArgs e)
        {
            WPFInPatient obj = new WPFInPatient();
            obj.Show();
            Close();
        }

        private void BtnOutPatient_Click(object sender, RoutedEventArgs e)
        {
            WPFOutPatient obj = new WPFOutPatient();
            obj.Show();
            Close();
        }

        private void BtnLab_Click(object sender, RoutedEventArgs e)
        {
            WPFLab obj = new WPFLab();
            obj.Show();
            Close();
        }

        private void BtnBill_Click(object sender, RoutedEventArgs e)
        {
            WPFBill obj = new WPFBill();
            obj.Show();
            Close();
        }             
    }
}
