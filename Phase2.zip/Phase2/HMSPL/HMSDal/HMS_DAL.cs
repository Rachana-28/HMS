﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HMSEntities;
using HMSExceptions;
using System.Configuration;

namespace HMSDal
{
    public class HMS_DAL
    {
        //PATIENT
        public bool AddPatientDAL(Patient objPatient)
        {
            bool patientAdded = false;
            SqlConnection Con = null;
            try
            {
                Con = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HMSConnection"].ConnectionString);
                SqlCommand Com = new SqlCommand("[46008221].InsertPatient", Con);
                Com.CommandType = CommandType.StoredProcedure;
                SqlParameter objSqlParam_PatientID = new SqlParameter("@PatientID", objPatient.PatientID);
                SqlParameter objSqlParam_DoctorID = new SqlParameter("@DoctorID", objPatient.DoctorID);
                SqlParameter objSqlParam_PatientName = new SqlParameter("@PatientName", objPatient.PatientName);
                SqlParameter objSqlParam_MobileNo = new SqlParameter("@MobileNo", objPatient.MobileNo);
                SqlParameter objSqlParam_Gender = new SqlParameter("@Gender", objPatient.Gender);
                SqlParameter objSqlParam_Age = new SqlParameter("@Age", objPatient.Age);
                SqlParameter objSqlParam_PatientWeight = new SqlParameter("@PatientWeight", objPatient.PatientWeight);
                SqlParameter objSqlParam_PatientAddress = new SqlParameter("@PatientAddress", objPatient.PatientAddress);
                SqlParameter objSqlParam_Disease = new SqlParameter("@Disease", objPatient.Disease);
                Com.Parameters.Add(objSqlParam_PatientID);
                Com.Parameters.Add(objSqlParam_DoctorID);
                Com.Parameters.Add(objSqlParam_PatientName);
                Com.Parameters.Add(objSqlParam_MobileNo);
                Com.Parameters.Add(objSqlParam_Gender);
                Com.Parameters.Add(objSqlParam_Age);
                Com.Parameters.Add(objSqlParam_PatientWeight);
                Com.Parameters.Add(objSqlParam_PatientAddress);
                Com.Parameters.Add(objSqlParam_Disease);
                Con.Open();
                Com.ExecuteNonQuery();
                patientAdded = true;
            }
            catch (SqlException objSqlEx)
            {
                throw new HMS_Exceptions(objSqlEx.Message);
            }
            finally
            {
                Con.Close();
            }
            return patientAdded;
        }
        public bool UpdatePatientDAL(Patient objPatient)
        {
            bool patientUpdated = false;
            SqlConnection Con = null;
            try
            {
                Con = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HMSConnection"].ConnectionString);
                SqlCommand Com = new SqlCommand("[46008221].UpdatePatient", Con);
                Com.CommandType = CommandType.StoredProcedure;              
                SqlParameter objSqlParam_PatientID = new SqlParameter("@PatientID", objPatient.PatientID);
                SqlParameter objSqlParam_DoctorID = new SqlParameter("@DoctorID", objPatient.DoctorID);
                SqlParameter objSqlParam_PatientName = new SqlParameter("@PatientName", objPatient.PatientName);
                SqlParameter objSqlParam_MobileNo = new SqlParameter("@MobileNo", objPatient.MobileNo);
                SqlParameter objSqlParam_Gender = new SqlParameter("@Gender", objPatient.Gender);
                SqlParameter objSqlParam_Age = new SqlParameter("@Age", objPatient.Age);
                SqlParameter objSqlParam_PatientWeight = new SqlParameter("@PatientWeight", objPatient.PatientWeight);
                SqlParameter objSqlParam_PatientAddress = new SqlParameter("@PatientAddress", objPatient.PatientAddress);
                SqlParameter objSqlParam_Disease = new SqlParameter("@Disease", objPatient.Gender);

                Com.Parameters.Add(objSqlParam_PatientID);
                Com.Parameters.Add(objSqlParam_DoctorID);
                Com.Parameters.Add(objSqlParam_PatientName);
                Com.Parameters.Add(objSqlParam_MobileNo);
                Com.Parameters.Add(objSqlParam_Gender);
                Com.Parameters.Add(objSqlParam_Age);
                Com.Parameters.Add(objSqlParam_PatientWeight);
                Com.Parameters.Add(objSqlParam_PatientAddress);
                Com.Parameters.Add(objSqlParam_Disease);

                Con.Open();
                Com.ExecuteNonQuery();
                patientUpdated = true;
            }
            catch (SqlException objSqlEx)
            {
                throw new HMS_Exceptions(objSqlEx.Message);
            }
            finally
            {
                Con.Close();
            }
            return patientUpdated;
        }

        public bool DeletePatientDAL(string patientID)
        {
            bool patientDeleted = false;
            SqlConnection Con = null;
            try
            {
                Con = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HMSConnection"].ConnectionString);
                SqlCommand Com = new SqlCommand("[46008221].DeletePatient", Con);
                Com.CommandType = CommandType.StoredProcedure;
          
                SqlParameter objSqlParam_PatientID = new SqlParameter("@PatientID", patientID);

             
                Com.Parameters.Add(objSqlParam_PatientID);

                Con.Open();
                Com.ExecuteNonQuery();
                patientDeleted = true;
            }
            catch (SqlException objSqlEx)
            {
                throw new HMS_Exceptions(objSqlEx.Message);
            }
            finally
            {
                Con.Close();
            }
            return patientDeleted;
        }

        public Patient SearchPatientbyPatientIDDAL(string PatientId)
        {
            Patient objPatient = null;
            SqlConnection Con = null;
            try
            {
                Con = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HMSConnection"].ConnectionString);
                SqlCommand Com = new SqlCommand("[46008221].SelectPatient", Con);
                Com.CommandType = CommandType.StoredProcedure;
                
                SqlParameter objSqlParam_PatientID = new SqlParameter("@PatientID", SqlDbType.VarChar, 20);
                SqlParameter objSqlParam_DoctorID = new SqlParameter("@DoctorID", SqlDbType.VarChar, 20);
                SqlParameter objSqlParam_PatientName = new SqlParameter("@PatientName", SqlDbType.VarChar, 20);
                SqlParameter objSqlParam_MobileNo = new SqlParameter("@MobileNo", SqlDbType.VarChar, 20);
                SqlParameter objSqlParam_Gender = new SqlParameter("@Gender", SqlDbType.VarChar, 10);
                SqlParameter objSqlParam_Age = new SqlParameter("@Age", SqlDbType.Int);
                SqlParameter objSqlParam_PatientWeight = new SqlParameter("@PatientWeight", SqlDbType.Float);
                SqlParameter objSqlParam_PatientAddress = new SqlParameter("@PatientAddress", SqlDbType.VarChar, 100);
                SqlParameter objSqlParam_Disease = new SqlParameter("@Disease", SqlDbType.VarChar, 100);
                
                objSqlParam_PatientID.Direction = ParameterDirection.Input;
                objSqlParam_DoctorID.Direction = ParameterDirection.Output;
                objSqlParam_PatientName.Direction = ParameterDirection.Output;
                objSqlParam_MobileNo.Direction = ParameterDirection.Output;
                objSqlParam_Gender.Direction = ParameterDirection.Output;
                objSqlParam_Age.Direction = ParameterDirection.Output;
                objSqlParam_PatientWeight.Direction = ParameterDirection.Output;
                objSqlParam_PatientAddress.Direction = ParameterDirection.Output;
                objSqlParam_Disease.Direction = ParameterDirection.Output;
                Com.Parameters.Add(objSqlParam_PatientID);
                Com.Parameters.Add(objSqlParam_DoctorID);
                Com.Parameters.Add(objSqlParam_PatientName);
                Com.Parameters.Add(objSqlParam_MobileNo);
                Com.Parameters.Add(objSqlParam_Gender);
                Com.Parameters.Add(objSqlParam_Age);
                Com.Parameters.Add(objSqlParam_PatientWeight);
                Com.Parameters.Add(objSqlParam_PatientAddress);
                Com.Parameters.Add(objSqlParam_Disease);

                
                objSqlParam_PatientID.Value = PatientId;
                Con.Open();
                Com.ExecuteNonQuery();
                objPatient = new Patient();
                objPatient.PatientID = objSqlParam_PatientID.Value as string;
                objPatient.DoctorID = objSqlParam_DoctorID.Value as string;
                objPatient.PatientName = objSqlParam_PatientName.Value as string;
                objPatient.MobileNo = objSqlParam_MobileNo.Value as string;
                objPatient.Gender = objSqlParam_Gender.Value as string;
                objPatient.Age = Convert.ToInt16(objSqlParam_Age.Value);
                objPatient.PatientWeight = Convert.ToDouble(objSqlParam_PatientWeight.Value);
                objPatient.PatientAddress = objSqlParam_PatientAddress.Value as string;
                objPatient.Disease = objSqlParam_Disease.Value as string;
            }
            catch (SqlException objSqlEx)
            {
                throw new HMS_Exceptions(objSqlEx.Message);
            }
            finally
            {
                Con.Close();
            }
            return objPatient;
        }


        public Patient SearchPatientbyDoctorIDDAL(string DoctorId)
        {
            Patient objPatient = null;
            SqlConnection Con = null;
            try
            {
                Con = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HMSConnection"].ConnectionString);
                SqlCommand Com = new SqlCommand("[46008221].SelectPatientByDoctor", Con);
                Com.CommandType = CommandType.StoredProcedure;

                SqlParameter objSqlParam_PatientID = new SqlParameter("@PatientID", SqlDbType.VarChar, 20);
                SqlParameter objSqlParam_DoctorID = new SqlParameter("@DoctorID", SqlDbType.VarChar, 20);
                SqlParameter objSqlParam_PatientName = new SqlParameter("@PatientName", SqlDbType.VarChar, 20);
                SqlParameter objSqlParam_MobileNo = new SqlParameter("@MobileNo", SqlDbType.VarChar, 20);
                SqlParameter objSqlParam_Gender = new SqlParameter("@Gender", SqlDbType.VarChar, 10);
                SqlParameter objSqlParam_Age = new SqlParameter("@Age", SqlDbType.Int);
                SqlParameter objSqlParam_PatientWeight = new SqlParameter("@PatientWeight", SqlDbType.Float);
                SqlParameter objSqlParam_PatientAddress = new SqlParameter("@PatientAddress", SqlDbType.VarChar, 100);
                SqlParameter objSqlParam_Disease = new SqlParameter("@Disease", SqlDbType.VarChar, 100);

                objSqlParam_PatientID.Direction = ParameterDirection.Output;
                objSqlParam_DoctorID.Direction = ParameterDirection.Input;
                objSqlParam_PatientName.Direction = ParameterDirection.Output;
                objSqlParam_MobileNo.Direction = ParameterDirection.Output;
                objSqlParam_Gender.Direction = ParameterDirection.Output;
                objSqlParam_Age.Direction = ParameterDirection.Output;
                objSqlParam_PatientWeight.Direction = ParameterDirection.Output;
                objSqlParam_PatientAddress.Direction = ParameterDirection.Output;
                objSqlParam_Disease.Direction = ParameterDirection.Output;

                Com.Parameters.Add(objSqlParam_PatientID);
                Com.Parameters.Add(objSqlParam_DoctorID);
                Com.Parameters.Add(objSqlParam_PatientName);
                Com.Parameters.Add(objSqlParam_MobileNo);
                Com.Parameters.Add(objSqlParam_Gender);
                Com.Parameters.Add(objSqlParam_Age);
                Com.Parameters.Add(objSqlParam_PatientWeight);
                Com.Parameters.Add(objSqlParam_PatientAddress);
                Com.Parameters.Add(objSqlParam_Disease);

                objSqlParam_DoctorID.Value = DoctorId;

                Con.Open();
                Com.ExecuteNonQuery();
                objPatient = new Patient();
                objPatient.PatientID = objSqlParam_PatientID.Value as string;
                objPatient.DoctorID = objSqlParam_DoctorID.Value as string;
                objPatient.PatientName = objSqlParam_PatientName.Value as string;
                objPatient.MobileNo = objSqlParam_MobileNo.Value as string;
                objPatient.Gender = objSqlParam_Gender.Value as string;
                objPatient.Age = Convert.ToInt16(objSqlParam_Age.Value);
                objPatient.PatientWeight = Convert.ToDouble(objSqlParam_PatientWeight.Value);
                objPatient.PatientAddress = objSqlParam_PatientAddress.Value as string;
                objPatient.Disease = objSqlParam_Disease.Value as string;
            }
            catch (SqlException objSqlEx)
            {
                throw new HMS_Exceptions(objSqlEx.Message);
            }
            finally
            {
                Con.Close();
            }
            return objPatient;
        }

        public List<Patient> GetAllPatientsDAL()
        {
            List<Patient> Patients = new List<Patient>();
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HMSConnection"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[46008221].ListPatient", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                
                objCon.Open();
                SqlDataReader objDR = objCom.ExecuteReader();
                while (objDR.Read())
                {
                    Patient objPatient = new Patient();
                    objPatient.PatientID = objDR[0] as string;
                    objPatient.DoctorID = objDR[8] as string;
                    objPatient.PatientName = objDR[1] as string;
                    objPatient.Gender = objDR[4] as string;
                    objPatient.MobileNo = objDR[6] as string;
                    objPatient.Age = Convert.ToInt32(objDR[2]);
                    objPatient.PatientWeight = Convert.ToDouble(objDR[3]);
                    objPatient.PatientAddress = objDR[5] as string;
                    objPatient.Disease = objDR[7] as string;



                    Patients.Add(objPatient);
                }
            }
            catch (SqlException objSqlEx)
            {
                throw new HMS_Exceptions(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return Patients;
        }


        //INPATIENT


        public bool AddInPatientDAL(InPatient objPatient)
        {
            bool InpatientAdded = false;
            SqlConnection Con = null;
            try
            {
                Con = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HMSConnection"].ConnectionString);
                SqlCommand Com = new SqlCommand("[46008221].Insert_InPatient", Con);
                Com.CommandType = CommandType.StoredProcedure;
                
                SqlParameter objSqlParam_PatientID = new SqlParameter("@PatientID", objPatient.PatientID);
                SqlParameter objSqlParam_RoomNo = new SqlParameter("@RoomNo", objPatient.RoomNo);
                SqlParameter objSqlParam_DoctorID = new SqlParameter("@DoctorID", objPatient.DoctorID);
                SqlParameter objSqlParam_AdmissionDate = new SqlParameter("@AdmissionDate", objPatient.AdmissionDate);
                SqlParameter objSqlParam_DischargeDate = new SqlParameter("@DischargeDate", objPatient.DischargeDate);
                SqlParameter objSqlParam_LabNo = new SqlParameter("@LabNo", objPatient.LabNo);
                SqlParameter objSqlParam_Amount = new SqlParameter("@Amount", objPatient.Amount);

                Com.Parameters.Add(objSqlParam_PatientID);
                Com.Parameters.Add(objSqlParam_RoomNo);
                Com.Parameters.Add(objSqlParam_DoctorID);
                Com.Parameters.Add(objSqlParam_AdmissionDate);
                Com.Parameters.Add(objSqlParam_DischargeDate);
                Com.Parameters.Add(objSqlParam_LabNo);
                Com.Parameters.Add(objSqlParam_Amount);

                Con.Open();
                Com.ExecuteNonQuery();
                InpatientAdded = true;
            }
            catch (SqlException objSqlEx)
            {
                throw new HMS_Exceptions(objSqlEx.Message);
            }
            finally
            {
                Con.Close();
            }
            return InpatientAdded;
        }
        public bool UpdateInPatientDAL(InPatient objPatient)
        {
            bool InpatientUpdated = false;
            SqlConnection Con = null;
            try
            {
                Con = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HMSConnection"].ConnectionString);
                SqlCommand Com = new SqlCommand("[46008221].Update_InPatient", Con);
                Com.CommandType = CommandType.StoredProcedure;
               
                SqlParameter objSqlParam_PatientID = new SqlParameter("@PatientID", objPatient.PatientID);
                SqlParameter objSqlParam_RoomNo = new SqlParameter("@RoomNo", objPatient.RoomNo);
                SqlParameter objSqlParam_DoctorID = new SqlParameter("@DoctorID", objPatient.DoctorID);
                SqlParameter objSqlParam_AdmissionDate = new SqlParameter("@AdmissionDate", objPatient.AdmissionDate);
                SqlParameter objSqlParam_DischargeDate = new SqlParameter("@DischargeDate", objPatient.DischargeDate);
                SqlParameter objSqlParam_LabNo = new SqlParameter("@LabNo", objPatient.LabNo);
                SqlParameter objSqlParam_Amount = new SqlParameter("@Amount", objPatient.Amount);

                Com.Parameters.Add(objSqlParam_PatientID);
                Com.Parameters.Add(objSqlParam_RoomNo);
                Com.Parameters.Add(objSqlParam_DoctorID);
                Com.Parameters.Add(objSqlParam_AdmissionDate);
                Com.Parameters.Add(objSqlParam_DischargeDate);
                Com.Parameters.Add(objSqlParam_LabNo);
                Com.Parameters.Add(objSqlParam_Amount);

                Con.Open();
                Com.ExecuteNonQuery();
                InpatientUpdated = true;
            }
            catch (SqlException objSqlEx)
            {
                throw new HMS_Exceptions(objSqlEx.Message);
            }
            finally
            {
                Con.Close();
            }
            return InpatientUpdated;
        }


        public bool DeleteInPatientDAL(string patientID)
        {
            bool InpatientDeleted = false;
            SqlConnection Con = null;
            try
            {
                Con = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HMSConnection"].ConnectionString);
                SqlCommand Com = new SqlCommand("[46008221].Delete_InPatient", Con);
                Com.CommandType = CommandType.StoredProcedure;
                
                SqlParameter objSqlParam_PatientID = new SqlParameter("@PatientID", patientID);

                Com.Parameters.Add(objSqlParam_PatientID);

                Con.Open();
                Com.ExecuteNonQuery();
                InpatientDeleted = true;
            }
            catch (SqlException objSqlEx)
            {
                throw new HMS_Exceptions(objSqlEx.Message);
            }
            finally
            {
                Con.Close();
            }
            return InpatientDeleted;
        }
        public InPatient SearchInPatientbyPatientIDDAL(string PatientId)
        {
            InPatient objPatient = null;
            SqlConnection Con = null;
            try
            {
                Con = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HMSConnection"].ConnectionString);
                SqlCommand Com = new SqlCommand("[46008221].Select_InPatient", Con);
                Com.CommandType = CommandType.StoredProcedure;
              
                SqlParameter objSqlParam_PatientID = new SqlParameter("@PatientID", SqlDbType.VarChar, 10);
                SqlParameter objSqlParam_RoomNo = new SqlParameter("@RoomNo", SqlDbType.VarChar, 20);
                SqlParameter objSqlParam_DoctorID = new SqlParameter("@DoctorID", SqlDbType.VarChar, 20);
                SqlParameter objSqlParam_AdmissionDate = new SqlParameter("@AdmissionDate", SqlDbType.Date);
                SqlParameter objSqlParam_DischargeDate = new SqlParameter("@DischargeDate", SqlDbType.Date);
                SqlParameter objSqlParam_LabNo = new SqlParameter("@LabNo", SqlDbType.VarChar, 20);
                SqlParameter objSqlParam_Amount = new SqlParameter("@Amount", SqlDbType.Real);

                objSqlParam_PatientID.Direction = ParameterDirection.Input;
                objSqlParam_RoomNo.Direction = ParameterDirection.Output;
                objSqlParam_DoctorID.Direction = ParameterDirection.Output;
                objSqlParam_AdmissionDate.Direction = ParameterDirection.Output;
                objSqlParam_DischargeDate.Direction = ParameterDirection.Output;
                objSqlParam_LabNo.Direction = ParameterDirection.Output;
                objSqlParam_Amount.Direction = ParameterDirection.Output;

                Com.Parameters.Add(objSqlParam_PatientID);
                Com.Parameters.Add(objSqlParam_RoomNo);
                Com.Parameters.Add(objSqlParam_DoctorID);
                Com.Parameters.Add(objSqlParam_AdmissionDate);
                Com.Parameters.Add(objSqlParam_DischargeDate);
                Com.Parameters.Add(objSqlParam_LabNo);
                Com.Parameters.Add(objSqlParam_Amount);

                objSqlParam_PatientID.Value = PatientId;
              
                Con.Open();
                Com.ExecuteNonQuery();
                objPatient = new InPatient();
                objPatient.PatientID = objSqlParam_PatientID.Value as string;
                objPatient.RoomNo = objSqlParam_RoomNo.Value as string;
                objPatient.DoctorID = objSqlParam_DoctorID.Value as string;
                objPatient.AdmissionDate = Convert.ToDateTime(objSqlParam_AdmissionDate.Value);
                objPatient.DischargeDate = Convert.ToDateTime(objSqlParam_DischargeDate.Value);
                objPatient.LabNo = objSqlParam_LabNo.Value as string;
                objPatient.Amount = Convert.ToDouble(objSqlParam_Amount.Value);

            }
            catch (SqlException objSqlEx)
            {
                throw new HMS_Exceptions(objSqlEx.Message);
            }
            finally
            {
                Con.Close();
            }
            return objPatient;
        }

               public List<InPatient> GetAllInPatientsDAL()
        {
            List<InPatient> InPatients = new List<InPatient>();
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HMSConnection"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[46008221].ListInPatient", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
            
                objCon.Open();
                SqlDataReader objDR = objCom.ExecuteReader();
                while (objDR.Read())
                {
                    InPatient objPatient = new InPatient();
                    objPatient.PatientID = objDR[0] as string;
                    objPatient.RoomNo = objDR[1] as string;
                    objPatient.DoctorID = objDR[2] as string;
                    objPatient.AdmissionDate = Convert.ToDateTime(objDR[3]);
                    objPatient.DischargeDate = Convert.ToDateTime(objDR[4]);

                    objPatient.LabNo = objDR[5] as string;
                    objPatient.Amount = Convert.ToDouble(objDR[6]);



                    InPatients.Add(objPatient);
                }
            }
            catch (SqlException objSqlEx)
            {
                throw new HMS_Exceptions(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return InPatients;
        }

        public DataTable GetDoctorDAL()
        {
            DataTable doctorList = null;
            SqlConnection objCon = null;
            try
            {

                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HMSConnection"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[46008221].GetDoctor",objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                
                objCon.Open();
                SqlDataReader objDR = objCom.ExecuteReader();
                doctorList = new DataTable();
                doctorList.Load(objDR);
            }
            catch (SqlException ex)
            {
                throw new HMS_Exceptions(ex.Message);
            }
            finally
            {
                objCon.Close();
            }
            return doctorList;
        }
        public DataTable GetPatientDAL()
        {
            DataTable patientList = null;
            SqlConnection objCon = null;
            try
            {

                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HMSConnection"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[46008221].ListPatient", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                
                objCon.Open();
                SqlDataReader objDR = objCom.ExecuteReader();
                patientList = new DataTable();
                patientList.Load(objDR);
            }
            catch (SqlException ex)
            {
                throw new HMS_Exceptions(ex.Message);
            }
            finally
            {
                objCon.Close();
            }
            return patientList;
        }
        public DataTable GetLabDAL()
        {
            DataTable labList = null;
            SqlConnection objCon = null;
            try
            {

                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HMSConnection"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[46008221].GetLab", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                
                objCon.Open();
                SqlDataReader objDR = objCom.ExecuteReader();
                labList = new DataTable();
                labList.Load(objDR);
            }
            catch (SqlException ex)
            {
                throw new HMS_Exceptions(ex.Message);
            }
            finally
            {
                objCon.Close();
            }
            return labList;
        }

        public DataTable GetRoomDAL()
        {
            DataTable roomList = null;
            SqlConnection objCon = null;
            try
            {

                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HMSConnection"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[46008221].GetRoom", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                
                objCon.Open();
                SqlDataReader objDR = objCom.ExecuteReader();
                roomList = new DataTable();
                roomList.Load(objDR);
            }
            catch (SqlException ex)
            {
                throw new HMS_Exceptions(ex.Message);
            }
            finally
            {
                objCon.Close();
            }
            return roomList;
        }

        //OUTPatient


        public bool AddOutPatientDAL(OutPatient objPatient)
        {
            bool OutpatientAdded = false;
            SqlConnection Con = null;
            try
            {
                Con = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HMSConnection"].ConnectionString);
                SqlCommand Com = new SqlCommand("[46008221].InsertOutPatient", Con);
                Com.CommandType = CommandType.StoredProcedure;
              
                SqlParameter objSqlParam_PatientID = new SqlParameter("@PatientID", objPatient.PatientID);
                SqlParameter objSqlParam_TreatmentDate = new SqlParameter("@TreatmentDate", objPatient.TreatmentDate);
                SqlParameter objSqlParam_DoctorID = new SqlParameter("@DoctorID", objPatient.DoctorID);
                SqlParameter objSqlParam_LabNo = new SqlParameter("@LabNo", objPatient.LabNo);

                Com.Parameters.Add(objSqlParam_PatientID);
                Com.Parameters.Add(objSqlParam_TreatmentDate);
                Com.Parameters.Add(objSqlParam_DoctorID);

                Com.Parameters.Add(objSqlParam_LabNo);

                Con.Open();
                Com.ExecuteNonQuery();
                OutpatientAdded = true;
            }
            catch (SqlException objSqlEx)
            {
                throw new HMS_Exceptions(objSqlEx.Message);
            }
            finally
            {
                Con.Close();
            }
            return OutpatientAdded;
        }
        public bool UpdateOutPatientDAL(OutPatient objPatient)
        {
            bool OutpatientUpdated = false;
            SqlConnection Con = null;
            try
            {
                Con = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HMSConnection"].ConnectionString);
                SqlCommand Com = new SqlCommand("[46008221].UpdateOutPatient", Con);
                Com.CommandType = CommandType.StoredProcedure;
                
                SqlParameter objSqlParam_PatientID = new SqlParameter("@PatientID", objPatient.PatientID);
                SqlParameter objSqlParam_TreatmentDate = new SqlParameter("@TreatmentDate", objPatient.TreatmentDate);
                SqlParameter objSqlParam_DoctorID = new SqlParameter("@DoctorID", objPatient.DoctorID);
                SqlParameter objSqlParam_LabNo = new SqlParameter("@LabNo", objPatient.LabNo);

                Com.Parameters.Add(objSqlParam_PatientID);
                Com.Parameters.Add(objSqlParam_TreatmentDate);
                Com.Parameters.Add(objSqlParam_DoctorID);
                Com.Parameters.Add(objSqlParam_LabNo);

                Con.Open();
                Com.ExecuteNonQuery();
                OutpatientUpdated = true;
            }
            catch (SqlException objSqlEx)
            {
                throw new HMS_Exceptions(objSqlEx.Message);
            }
            finally
            {
                Con.Close();
            }
            return OutpatientUpdated;
        }


        public bool DeleteOutPatientDAL(string patientID)
        {
            bool OutpatientDeleted = false;
            SqlConnection Con = null;
            try
            {
                Con = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HMSConnection"].ConnectionString);
                SqlCommand Com = new SqlCommand("[46008221].DeleteOutPatient", Con);
                Com.CommandType = CommandType.StoredProcedure;
                SqlParameter objSqlParam_PatientID = new SqlParameter("@PatientID", patientID);
                Com.Parameters.Add(objSqlParam_PatientID);

                Con.Open();
                Com.ExecuteNonQuery();
                OutpatientDeleted = true;
            }
            catch (SqlException objSqlEx)
            {
                throw new HMS_Exceptions(objSqlEx.Message);
            }
            finally
            {
                Con.Close();
            }
            return OutpatientDeleted;
        }
        public OutPatient SearchOutPatientbyPatientIDDAL(string PatientId)
        {
            OutPatient objPatient = null;
            SqlConnection Con = null;
            try
            {
                Con = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HMSConnection"].ConnectionString);
                SqlCommand Com = new SqlCommand("[46008221].SelectOutPatient", Con);
                Com.CommandType = CommandType.StoredProcedure;
                
                SqlParameter objSqlParam_PatientID = new SqlParameter("@PatientID", SqlDbType.VarChar, 10);
                SqlParameter objSqlParam_TreatmentDate = new SqlParameter("@TreatmentDate", SqlDbType.Date);
                SqlParameter objSqlParam_DoctorID = new SqlParameter("@DoctorID", SqlDbType.VarChar, 20);
                SqlParameter objSqlParam_LabNo = new SqlParameter("@LabNo", SqlDbType.VarChar, 20);

                objSqlParam_PatientID.Direction = ParameterDirection.Input;
                objSqlParam_TreatmentDate.Direction = ParameterDirection.Output;
                objSqlParam_DoctorID.Direction = ParameterDirection.Output;
                objSqlParam_LabNo.Direction = ParameterDirection.Output;

                Com.Parameters.Add(objSqlParam_PatientID);
                Com.Parameters.Add(objSqlParam_TreatmentDate);
                Com.Parameters.Add(objSqlParam_DoctorID);
                Com.Parameters.Add(objSqlParam_LabNo);

                objSqlParam_PatientID.Value = PatientId;
               
                Con.Open();
                Com.ExecuteNonQuery();
                objPatient = new OutPatient();
                objPatient.PatientID = objSqlParam_PatientID.Value as string;
                objPatient.TreatmentDate = Convert.ToDateTime(objSqlParam_TreatmentDate.Value);
                objPatient.DoctorID = objSqlParam_DoctorID.Value as string;

                objPatient.LabNo = objSqlParam_LabNo.Value as string;


            }
            catch (SqlException objSqlEx)
            {
                throw new HMS_Exceptions(objSqlEx.Message);
            }
            finally
            {
                Con.Close();
            }
            return objPatient;
        }

        public List<OutPatient> GetAllOutPatientsDAL()
        {
            List<OutPatient> OutPatients = new List<OutPatient>();
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HMSConnection"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[46008221].ListOutPatient", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
               
                objCon.Open();
                SqlDataReader objDR = objCom.ExecuteReader();
                while (objDR.Read())
                {
                    OutPatient objPatient = new OutPatient();
                    objPatient.PatientID = objDR[0] as string;
                    objPatient.TreatmentDate = Convert.ToDateTime(objDR[1]);
                    objPatient.DoctorID = objDR[2] as string;



                    objPatient.LabNo = objDR[3] as string;




                    OutPatients.Add(objPatient);
                }
            }
            catch (SqlException objSqlEx)
            {
                throw new HMS_Exceptions(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return OutPatients;
        }

        //LAB

        public bool AddLabDAL(Lab objlab)
        {
            bool LabAdded = false;
            SqlConnection Con = null;
            try
            {
                Con = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HMSConnection"].ConnectionString);
                SqlCommand Com = new SqlCommand("[46008221].InsertLab", Con);
                Com.CommandType = CommandType.StoredProcedure;
              
                SqlParameter objSqlParam_LabNo = new SqlParameter("@LabNo", objlab.LabNo);
                SqlParameter objSqlParam_PatientID = new SqlParameter("@PatientID", objlab.PatientID);
                SqlParameter objSqlParam_DoctorID = new SqlParameter("@DoctorID", objlab.DoctorID);
                SqlParameter objSqlParam_TestDate = new SqlParameter("@TestDate", objlab.TestDate);
                SqlParameter objSqlParam_TestType = new SqlParameter("@TestType", objlab.TestType);
                SqlParameter objSqlParam_PatientType = new SqlParameter("@PatientType", objlab.PatientType);

                Com.Parameters.Add(objSqlParam_LabNo);
                Com.Parameters.Add(objSqlParam_PatientID);
                Com.Parameters.Add(objSqlParam_DoctorID);
                Com.Parameters.Add(objSqlParam_TestDate);
                Com.Parameters.Add(objSqlParam_TestType);
                Com.Parameters.Add(objSqlParam_PatientType);

                Con.Open();
                Com.ExecuteNonQuery();
                LabAdded = true;
            }
            catch (SqlException objSqlEx)
            {
                throw new HMS_Exceptions(objSqlEx.Message);
            }
            finally
            {
                Con.Close();
            }
            return LabAdded;
        }
        public bool UpdateLabDAL(Lab objLab)
        {
            bool LabUpdated = false;
            SqlConnection Con = null;
            try
            {
                Con = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HMSConnection"].ConnectionString);
                SqlCommand Com = new SqlCommand("[46008221].UpdateLab", Con);
                Com.CommandType = CommandType.StoredProcedure;
               
                SqlParameter objSqlParam_LabNo = new SqlParameter("@LabNo", objLab.LabNo);
                SqlParameter objSqlParam_PatientID = new SqlParameter("@PatientID", objLab.PatientID);
                SqlParameter objSqlParam_DoctorID = new SqlParameter("@DoctorID", objLab.DoctorID);
                SqlParameter objSqlParam_TestDate = new SqlParameter("@TestDate", objLab.TestDate);
                SqlParameter objSqlParam_TestType = new SqlParameter("@TestType", objLab.TestType);
                SqlParameter objSqlParam_PatientType = new SqlParameter("@PatientType", objLab.PatientType);


                Com.Parameters.Add(objSqlParam_LabNo);
                Com.Parameters.Add(objSqlParam_PatientID);
                Com.Parameters.Add(objSqlParam_DoctorID);
                Com.Parameters.Add(objSqlParam_TestDate);
                Com.Parameters.Add(objSqlParam_TestType);
                Com.Parameters.Add(objSqlParam_PatientType);

                Con.Open();
                Com.ExecuteNonQuery();
                LabUpdated = true;
            }
            catch (SqlException objSqlEx)
            {
                throw new HMS_Exceptions(objSqlEx.Message);
            }
            finally
            {
                Con.Close();
            }
            return LabUpdated;
        }


        public bool DeleteLabDAL(string LabId)
        {
            bool LabDeleted = false;
            SqlConnection Con = null;
            try
            {
                Con = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HMSConnection"].ConnectionString);
                SqlCommand Com = new SqlCommand("[46008221].DeleteLab", Con);
                Com.CommandType = CommandType.StoredProcedure;
                
                SqlParameter objSqlParam_LabID = new SqlParameter("@LabNo",LabId);

                Com.Parameters.Add(objSqlParam_LabID);

                Con.Open();
                Com.ExecuteNonQuery();
                LabDeleted = true;
            }
            catch (SqlException objSqlEx)
            {
                throw new HMS_Exceptions(objSqlEx.Message);
            }
            finally
            {
                Con.Close();
            }
            return LabDeleted;
        }
        public Lab SearchLabbyPatientIDDAL(string LabId)
        {
            Lab objLab = null;
            SqlConnection Con = null;
            try
            {
                Con = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HMSConnection"].ConnectionString);
                SqlCommand Com = new SqlCommand("[46008221].SelectLab", Con);
                Com.CommandType = CommandType.StoredProcedure;
             
                SqlParameter objSqlParam_LabNo = new SqlParameter("@LabNo", SqlDbType.VarChar, 20);
                SqlParameter objSqlParam_PatientID = new SqlParameter("@PatientID", SqlDbType.VarChar, 10);
                SqlParameter objSqlParam_DoctorID = new SqlParameter("@DoctorID", SqlDbType.VarChar, 20);
                SqlParameter objSqlParam_TestDate = new SqlParameter("@TestDate", SqlDbType.Date);
                SqlParameter objSqlParam_TestType = new SqlParameter("@TestType", SqlDbType.VarChar, 20);
                SqlParameter objSqlParam_PatientType = new SqlParameter("@PatientType", SqlDbType.VarChar, 20);

                objSqlParam_LabNo.Direction = ParameterDirection.Input;
                objSqlParam_PatientID.Direction = ParameterDirection.Output;
                objSqlParam_DoctorID.Direction = ParameterDirection.Output;
                objSqlParam_TestDate.Direction = ParameterDirection.Output;
                objSqlParam_TestType.Direction = ParameterDirection.Output;
                objSqlParam_PatientType.Direction = ParameterDirection.Output;

                Com.Parameters.Add(objSqlParam_LabNo);
                Com.Parameters.Add(objSqlParam_PatientID);
                Com.Parameters.Add(objSqlParam_DoctorID);
                Com.Parameters.Add(objSqlParam_TestDate);
                Com.Parameters.Add(objSqlParam_TestType);
                Com.Parameters.Add(objSqlParam_PatientType);

                objSqlParam_LabNo.Value = LabId;
             
                Con.Open();
                Com.ExecuteNonQuery();
                objLab = new Lab();
                //objLab.LabNo = LabId;
                objLab.PatientID = objSqlParam_LabNo.Value as string;
                objLab.DoctorID = objSqlParam_DoctorID.Value as string;
                objLab.TestDate = Convert.ToDateTime(objSqlParam_TestDate.Value);
                objLab.TestType = objSqlParam_TestType.Value as string;
                objLab.PatientType = objSqlParam_PatientType.Value as string;

            }
            catch (SqlException objSqlEx)
            {
                throw new HMS_Exceptions(objSqlEx.Message);
            }
            finally
            {
                Con.Close();
            }
            return objLab;
        }



        public List<Lab> GetAllLabsDAL()
        {
            List<Lab> Labs = new List<Lab>();
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HMSConnection"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[46008221].GetLab", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
               
                objCon.Open();
                SqlDataReader objDR = objCom.ExecuteReader();
                while (objDR.Read())
                {
                    Lab objLab = new Lab();
                    objLab.LabNo = objDR[0] as string;
                    objLab.PatientID = objDR[1] as string;
                    objLab.DoctorID = objDR[2] as string;
                    objLab.TestDate = Convert.ToDateTime(objDR[3]);
                    objLab.TestType = objDR[4] as string;
                    objLab.PatientType = objDR[5] as string;
                    Labs.Add(objLab);
                }
            }
            catch (SqlException objSqlEx)
            {
                throw new HMS_Exceptions(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return Labs;
        }



        //BILL

        public bool AddBillDAL(Bill objBill)
        {
            bool BillAdded = false;
            SqlConnection Con = null;
            try
            {
                Con = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HMSConnection"].ConnectionString);
                SqlCommand Com = new SqlCommand("[46008221].InsertBill", Con);
                Com.CommandType = CommandType.StoredProcedure;
              
                SqlParameter objSqlParam_BillID = new SqlParameter("@BillNo", objBill.BillID);
                SqlParameter objSqlParam_PatientID = new SqlParameter("@PatientID", objBill.PatientID);
                SqlParameter objSqlParam_PatientType = new SqlParameter("@PatientType", objBill.PatientType);
                SqlParameter objSqlParam_DoctorID = new SqlParameter("@DoctorID", objBill.DoctorID);
                SqlParameter objSqlParam_DoctorFees = new SqlParameter("@DoctorFee", objBill.DoctorFees);
                SqlParameter objSqlParam_RoomCharges = new SqlParameter("@RoomCharge", objBill.RoomCharges);
                SqlParameter objSqlParam_OperationCharges = new SqlParameter("@OperationCharges", objBill.OperationCharges);
                SqlParameter objSqlParam_MedicineFees = new SqlParameter("@MedicineFee", objBill.MedicineFees);
                SqlParameter objSqlParam_TotalDays = new SqlParameter("@TotalDays", objBill.TotalDays);
                SqlParameter objSqlParam_LabFees = new SqlParameter("@LabFee", objBill.LabFees);
                SqlParameter objSqlParam_TotalAmount = new SqlParameter("@TotalAmount", objBill.TotalAmount);
              
                Com.Parameters.Add(objSqlParam_BillID);
                Com.Parameters.Add(objSqlParam_PatientID);
                Com.Parameters.Add(objSqlParam_PatientType);
                Com.Parameters.Add(objSqlParam_DoctorID);
                Com.Parameters.Add(objSqlParam_DoctorFees);
                Com.Parameters.Add(objSqlParam_RoomCharges);
                Com.Parameters.Add(objSqlParam_OperationCharges);
                Com.Parameters.Add(objSqlParam_MedicineFees);
                Com.Parameters.Add(objSqlParam_TotalDays);
                Com.Parameters.Add(objSqlParam_LabFees);
                Com.Parameters.Add(objSqlParam_TotalAmount);

                Con.Open();
                Com.ExecuteNonQuery();
                BillAdded = true;
            }
            catch (SqlException objSqlEx)
            {
                throw new HMS_Exceptions(objSqlEx.Message);
            }
            finally
            {
                Con.Close();
            }
            return BillAdded;
        }
        public bool UpdateBillDAL(Bill objBill)
        {
            bool BillUpdated = false;
            SqlConnection Con = null;
            try
            {
                Con = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HMSConnection"].ConnectionString);
                SqlCommand Com = new SqlCommand("[46008221].UpdateBill", Con);
                Com.CommandType = CommandType.StoredProcedure;
               
                SqlParameter objSqlParam_BillID = new SqlParameter("@BillNo", objBill.BillID);
                SqlParameter objSqlParam_PatientID = new SqlParameter("@PatientID", objBill.PatientID);
                SqlParameter objSqlParam_PatientType = new SqlParameter("@PatientType", objBill.PatientType);
                SqlParameter objSqlParam_DoctorID = new SqlParameter("@DoctorID", objBill.DoctorID);
                SqlParameter objSqlParam_DoctorFees = new SqlParameter("@DoctorFee", objBill.DoctorFees);
                SqlParameter objSqlParam_RoomCharges = new SqlParameter("@RoomCharge", objBill.RoomCharges);
                SqlParameter objSqlParam_OperationCharges = new SqlParameter("@OperationCharges", objBill.OperationCharges);
                SqlParameter objSqlParam_MedicineFees = new SqlParameter("@MedicineFee", objBill.MedicineFees);
                SqlParameter objSqlParam_TotalDays = new SqlParameter("@TotalDays", objBill.TotalDays);
                SqlParameter objSqlParam_LabFees = new SqlParameter("@LabFee", objBill.LabFees);
                SqlParameter objSqlParam_TotalAmount = new SqlParameter("@TotalAmount", objBill.TotalAmount);
              
                Com.Parameters.Add(objSqlParam_BillID);
                Com.Parameters.Add(objSqlParam_PatientID);
                Com.Parameters.Add(objSqlParam_PatientType);
                Com.Parameters.Add(objSqlParam_DoctorID);
                Com.Parameters.Add(objSqlParam_DoctorFees);
                Com.Parameters.Add(objSqlParam_RoomCharges);
                Com.Parameters.Add(objSqlParam_OperationCharges);
                Com.Parameters.Add(objSqlParam_MedicineFees);
                Com.Parameters.Add(objSqlParam_TotalDays);
                Com.Parameters.Add(objSqlParam_LabFees);
                Com.Parameters.Add(objSqlParam_TotalAmount);

                Con.Open();
                Com.ExecuteNonQuery();
                BillUpdated = true;
            }
            catch (SqlException objSqlEx)
            {
                throw new HMS_Exceptions(objSqlEx.Message);
            }
            finally
            {
                Con.Close();
            }
            return BillUpdated;
        }


        public bool DeleteBillDAL(string billID)
        {
            bool billDeleted = false;
            SqlConnection Con = null;
            try
            {
                Con = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HMSConnection"].ConnectionString);
                SqlCommand Com = new SqlCommand("[46008221].DeleteBill", Con);
                Com.CommandType = CommandType.StoredProcedure;
                SqlParameter objSqlParam_PatientID = new SqlParameter("@BillID", billID);
                Com.Parameters.Add(objSqlParam_PatientID);
                Con.Open();
                Com.ExecuteNonQuery();
                billDeleted = true;
            }
            catch (SqlException objSqlEx)
            {
                throw new HMS_Exceptions(objSqlEx.Message);
            }
            finally
            {
                Con.Close();
            }
            return billDeleted;
        }
        public Bill SearchBillbyBillIDDAL(string BillId)
        {
            Bill objBill = null;
            SqlConnection Con = null;
            try
            {
                Con = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HMSConnection"].ConnectionString);
                SqlCommand Com = new SqlCommand("[46008221].SelectBill", Con);
                Com.CommandType = CommandType.StoredProcedure;
               
                SqlParameter objSqlParam_BillID = new SqlParameter("@BillNo", SqlDbType.VarChar, 20);
                SqlParameter objSqlParam_PatientID = new SqlParameter("@PatientID", SqlDbType.VarChar, 20);
                SqlParameter objSqlParam_PatientType = new SqlParameter("@PatientType", SqlDbType.VarChar, 20);
                SqlParameter objSqlParam_DoctorID = new SqlParameter("@DoctorID", SqlDbType.VarChar, 20);
                SqlParameter objSqlParam_DoctorFees = new SqlParameter("@DoctorFee", SqlDbType.Real);
                SqlParameter objSqlParam_RoomCharges = new SqlParameter("@RoomCharge", SqlDbType.Real);
                SqlParameter objSqlParam_OperationCharges = new SqlParameter("@OperationCharges", SqlDbType.Real);
                SqlParameter objSqlParam_MedicineFees = new SqlParameter("@MedicineFee", SqlDbType.Real);
                SqlParameter objSqlParam_TotalDays = new SqlParameter("@TotalDays", SqlDbType.Int);
                SqlParameter objSqlParam_LabFees = new SqlParameter("@LabFee", SqlDbType.Real);
                SqlParameter objSqlParam_TotalAmount = new SqlParameter("@TotalAmount", SqlDbType.Real);
                
                objSqlParam_BillID.Direction = ParameterDirection.Input;
                objSqlParam_PatientID.Direction = ParameterDirection.Output;
                objSqlParam_PatientType.Direction = ParameterDirection.Output;
                objSqlParam_DoctorID.Direction = ParameterDirection.Output;
                objSqlParam_DoctorFees.Direction = ParameterDirection.Output;
                objSqlParam_RoomCharges.Direction = ParameterDirection.Output;
                objSqlParam_OperationCharges.Direction = ParameterDirection.Output;
                objSqlParam_MedicineFees.Direction = ParameterDirection.Output;
                objSqlParam_TotalDays.Direction = ParameterDirection.Output;
                objSqlParam_LabFees.Direction = ParameterDirection.Output;
                objSqlParam_TotalAmount.Direction = ParameterDirection.Output;

                Com.Parameters.Add(objSqlParam_BillID);
                Com.Parameters.Add(objSqlParam_PatientID);
                Com.Parameters.Add(objSqlParam_PatientType);
                Com.Parameters.Add(objSqlParam_DoctorID);
                Com.Parameters.Add(objSqlParam_RoomCharges);
                Com.Parameters.Add(objSqlParam_DoctorFees);
                Com.Parameters.Add(objSqlParam_OperationCharges);
                Com.Parameters.Add(objSqlParam_MedicineFees);
                Com.Parameters.Add(objSqlParam_TotalDays);
                Com.Parameters.Add(objSqlParam_LabFees);
                Com.Parameters.Add(objSqlParam_TotalAmount);

                objSqlParam_BillID.Value = BillId;
              
                Con.Open();
                Com.ExecuteNonQuery();
                objBill = new Bill();
                objBill.BillID = objSqlParam_BillID.Value as string;
                objBill.PatientID = objSqlParam_PatientID.Value as string;
                objBill.PatientType = objSqlParam_PatientType.Value as string;
                objBill.DoctorID = objSqlParam_DoctorID.Value as string;
                objBill.DoctorFees = Convert.ToDouble(objSqlParam_DoctorFees.Value);
                objBill.RoomCharges = Convert.ToDouble(objSqlParam_RoomCharges.Value);
                objBill.OperationCharges = Convert.ToDouble(objSqlParam_OperationCharges.Value);
                objBill.MedicineFees = Convert.ToDouble(objSqlParam_MedicineFees.Value);
                objBill.LabFees = Convert.ToDouble(objSqlParam_LabFees.Value);
                objBill.TotalDays = Convert.ToInt32(objSqlParam_TotalDays.Value);
                objBill.TotalAmount = Convert.ToDouble(objSqlParam_TotalAmount.Value);

            }
            catch (SqlException objSqlEx)
            {
                throw new HMS_Exceptions(objSqlEx.Message);
            }
            finally
            {
                Con.Close();
            }
            return objBill;
        }


        public List<Bill> GetAllBillsDAL()
        {
            List<Bill> bills = new List<Bill>();
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HMSConnection"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[46008221].ListBill", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
               
                objCon.Open();
                SqlDataReader objDR = objCom.ExecuteReader();
                while (objDR.Read())
                {
                    Bill objBill = new Bill();
                    objBill.BillID = objDR[0] as string;
                    objBill.PatientID = objDR[1] as string;
                    objBill.PatientType = objDR[2] as string;
                    objBill.DoctorID = objDR[3] as string;
                    objBill.DoctorFees = Convert.ToDouble(objDR[4]);
                    objBill.RoomCharges = Convert.ToDouble(objDR[5]);
                    objBill.OperationCharges = Convert.ToDouble(objDR[6]);
                    objBill.MedicineFees = Convert.ToDouble(objDR[7]);
                    objBill.TotalDays = Convert.ToInt32(objDR[8]);
                    objBill.LabFees = Convert.ToDouble(objDR[9]);
                    objBill.TotalAmount = Convert.ToDouble(objDR[10]);



                    bills.Add(objBill);
                }
            }
            catch (SqlException objSqlEx)
            {
                throw new HMS_Exceptions(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return bills;
        }
    }
}

