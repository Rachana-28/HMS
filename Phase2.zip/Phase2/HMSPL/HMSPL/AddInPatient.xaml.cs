﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using HMSBal;
using HMSEntities;
using HMSExceptions;

namespace HMSPL
{
    /// <summary>
    /// Interaction logic for AddInPatient.xaml
    /// </summary>
    public partial class AddInPatient : Window
    {
        public AddInPatient()
        {
            InitializeComponent();
        }

        private void Addinpatient_Click(object sender, RoutedEventArgs e)
        {
            AddInpatient();

        }

        private void GetDoctors()

        {

            try

            {

                DataTable doctorsList = HMS_BAL.GetDoctorsBL();

                cbdid.ItemsSource = doctorsList.DefaultView;

                cbdid.DisplayMemberPath = doctorsList.Columns[0].ColumnName;

                cbdid.SelectedValuePath = doctorsList.Columns[0].ColumnName;

            }

            catch (HMS_Exceptions ex)

            {

                MessageBox.Show(ex.Message);

            }

        }

        private void GetPatients()

        {

            try

            {

                DataTable patientList = HMS_BAL.GetPatientBL();

                cbpatientid.ItemsSource = patientList.DefaultView;

                cbpatientid.DisplayMemberPath = patientList.Columns[0].ColumnName;

                cbpatientid.SelectedValuePath = patientList.Columns[0].ColumnName;

            }

            catch (HMS_Exceptions ex)

            {

                MessageBox.Show(ex.Message);

            }

        }


        private void AddInpatient()
        {

            try
            {

                int patientid;
                int doctorid;
                int roomno;
                DateTime admissiondate;
                DateTime dischargedate;
                int labid;

                bool Inpatientadded;

                patientid = Convert.ToInt32(cbpatientid.SelectedValue);
                doctorid = Convert.ToInt32(cbdid.SelectedValue);
                roomno = Convert.ToInt32(txtroomno.Text);
                admissiondate = Convert.ToDateTime(txtadmissiondate.ToString());
                dischargedate = Convert.ToDateTime(txtdischargedate.ToString());
                labid = Convert.ToInt32(txtlabid.Text);

                InPatient objInpatient = new InPatient
                {
                    PatientID = patientid,
                    DoctorID = doctorid,
                    RoomNo = roomno,
                    AdmissionDate = admissiondate,
                    DisChargeDate = dischargedate,
                    LabID = labid
                };

                Inpatientadded = HMS_BAL.AddInPatientBL(objInpatient);
                if (Inpatientadded == true)
                {
                    MessageBox.Show("Inatient Record added Sucessfully.");
                }
                else
                {
                    MessageBox.Show("InPatient Record Couldn't be Added.");
                }


            }

            catch (HMS_Exceptions ex)
            {

                MessageBox.Show(ex.Message);
            }
        }
    

        private void BackInpatient_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            GetDoctors();
            GetPatients();
        }
    }
}
